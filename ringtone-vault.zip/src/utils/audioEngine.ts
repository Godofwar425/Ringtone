// Web Audio API Sound Engine for Ringtone Vault
// Synthesizes ringtones on the fly, renders waveforms, and exports downloadable WAV blobs.

let audioCtx: AudioContext | null = null;

export function getAudioContext(): AudioContext {
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    audioCtx = new AudioContextClass();
  }
  if (audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

// Convert AudioBuffer to downloadable 16-bit PCM WAV Blob
export function bufferToWaveBlob(abuffer: AudioBuffer): Blob {
  const numOfChan = abuffer.numberOfChannels;
  const length = abuffer.length * numOfChan * 2 + 44;
  const out = new ArrayBuffer(length);
  const view = new DataView(out);
  const channels: Float32Array[] = [];
  let sample: number = 0;
  let offset = 0;
  let pos = 0;

  // write WAVE header
  function setUint16(data: number) {
    view.setUint16(pos, data, true);
    pos += 2;
  }
  function setUint32(data: number) {
    view.setUint32(pos, data, true);
    pos += 4;
  }

  // RIFF identifier
  view.setUint8(pos++, 'R'.charCodeAt(0));
  view.setUint8(pos++, 'I'.charCodeAt(0));
  view.setUint8(pos++, 'F'.charCodeAt(0));
  view.setUint8(pos++, 'F'.charCodeAt(0));
  setUint32(length - 8); // file length - 8
  view.setUint8(pos++, 'W'.charCodeAt(0));
  view.setUint8(pos++, 'A'.charCodeAt(0));
  view.setUint8(pos++, 'V'.charCodeAt(0));
  view.setUint8(pos++, 'E'.charCodeAt(0));

  // format chunk identifier
  view.setUint8(pos++, 'f'.charCodeAt(0));
  view.setUint8(pos++, 'm'.charCodeAt(0));
  view.setUint8(pos++, 't'.charCodeAt(0));
  view.setUint8(pos++, ' '.charCodeAt(0));
  setUint32(16); // format chunk length
  setUint16(1); // sample format (raw PCM)
  setUint16(numOfChan); // channel count
  setUint32(abuffer.sampleRate); // sample rate
  setUint32(abuffer.sampleRate * 2 * numOfChan); // byte rate (sample rate * block align)
  setUint16(numOfChan * 2); // block align (channel count * bytes per sample)
  setUint16(16); // bits per sample

  // data chunk identifier
  view.setUint8(pos++, 'd'.charCodeAt(0));
  view.setUint8(pos++, 'a'.charCodeAt(0));
  view.setUint8(pos++, 't'.charCodeAt(0));
  view.setUint8(pos++, 'a'.charCodeAt(0));
  setUint32(length - pos - 4); // data chunk length

  for (let i = 0; i < abuffer.numberOfChannels; i++) {
    channels.push(abuffer.getChannelData(i));
  }

  while (pos < length && offset < abuffer.length) {
    for (let i = 0; i < numOfChan; i++) {
      sample = Math.max(-1, Math.min(1, channels[i][offset])); // clamp
      sample = (0.5 + sample < 0 ? sample * 32768 : sample * 32767) | 0; // scale to 16-bit signed int
      view.setInt16(pos, sample, true);
      pos += 2;
    }
    offset++;
  }

  return new Blob([out], { type: 'audio/wav' });
}

// Frequency note helper
const NOTE_FREQ: Record<string, number> = {
  'C3': 130.81, 'D3': 146.83, 'E3': 164.81, 'F3': 174.61, 'G3': 196.00, 'A3': 220.00, 'B3': 246.94,
  'C4': 261.63, 'C#4': 277.18, 'D4': 293.66, 'D#4': 311.13, 'E4': 329.63, 'F4': 349.23, 'F#4': 369.99,
  'G4': 392.00, 'G#4': 415.30, 'A4': 440.00, 'A#4': 466.16, 'B4': 493.88,
  'C5': 523.25, 'C#5': 554.37, 'D5': 587.33, 'D#5': 622.25, 'E5': 659.25, 'F5': 698.46, 'F#5': 739.99,
  'G5': 783.99, 'G#5': 830.61, 'A5': 880.00, 'A#5': 932.33, 'B5': 987.77,
  'C6': 1046.50, 'D6': 1174.66, 'E6': 1318.51, 'G6': 1567.98, 'A6': 1760.00
};

// Render synthetic preset to AudioBuffer for offline export or real-time playback
export async function renderPresetAudioBuffer(preset: string, totalSeconds = 12): Promise<AudioBuffer> {
  const sampleRate = 44100;
  const offlineCtx = new OfflineAudioContext(2, sampleRate * totalSeconds, sampleRate);

  const masterGain = offlineCtx.createGain();
  masterGain.gain.setValueAtTime(0.75, 0);
  masterGain.connect(offlineCtx.destination);

  // Helper note trigger for offline synthesis
  const playNote = (
    note: string,
    time: number,
    duration: number,
    type: OscillatorType = 'sine',
    gainVal = 0.3,
    filterFreq = 3000
  ) => {
    const freq = NOTE_FREQ[note] || 440;
    const osc = offlineCtx.createOscillator();
    const gain = offlineCtx.createGain();
    const filter = offlineCtx.createBiquadFilter();

    osc.type = type;
    osc.frequency.setValueAtTime(freq, time);

    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(filterFreq, time);

    gain.gain.setValueAtTime(0.001, time);
    gain.gain.exponentialRampToValueAtTime(gainVal, time + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, time + duration);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(masterGain);

    osc.start(time);
    osc.stop(time + duration + 0.05);
  };

  const playKick = (time: number) => {
    const osc = offlineCtx.createOscillator();
    const gain = offlineCtx.createGain();
    osc.frequency.setValueAtTime(140, time);
    osc.frequency.exponentialRampToValueAtTime(35, time + 0.15);
    gain.gain.setValueAtTime(0.7, time);
    gain.gain.exponentialRampToValueAtTime(0.001, time + 0.2);
    osc.connect(gain);
    gain.connect(masterGain);
    osc.start(time);
    osc.stop(time + 0.25);
  };

  const playHiHat = (time: number) => {
    const osc = offlineCtx.createOscillator();
    const gain = offlineCtx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(8000, time);
    gain.gain.setValueAtTime(0.12, time);
    gain.gain.exponentialRampToValueAtTime(0.001, time + 0.04);
    osc.connect(gain);
    gain.connect(masterGain);
    osc.start(time);
    osc.stop(time + 0.05);
  };

  switch (preset) {
    case 'cyberpunk': {
      // Synthwave arpeggios
      const bassNotes = ['A3', 'C4', 'E4', 'G4', 'A4', 'G4', 'E4', 'C4'];
      const leadNotes = ['A5', 'G5', 'E5', 'C5', 'D5', 'E5', 'G5', 'A5'];
      for (let loop = 0; loop < 4; loop++) {
        const loopOffset = loop * 3.0;
        for (let i = 0; i < 8; i++) {
          const t = loopOffset + i * 0.35;
          playNote(bassNotes[i], t, 0.3, 'sawtooth', 0.25, 1200);
          if (i % 2 === 0) playKick(t);
          playHiHat(t + 0.175);
          if (loop >= 1) {
            playNote(leadNotes[i], t, 0.45, 'square', 0.18, 2500);
          }
        }
      }
      break;
    }

    case 'marimba': {
      // Playful upbeat marimba melody
      const melody = [
        { note: 'E5', d: 0.2 }, { note: 'G5', d: 0.2 }, { note: 'A5', d: 0.3 },
        { note: 'C6', d: 0.4 }, { note: 'A5', d: 0.2 }, { note: 'G5', d: 0.2 },
        { note: 'E5', d: 0.4 }, { note: 'D5', d: 0.2 }, { note: 'E5', d: 0.5 }
      ];
      for (let loop = 0; loop < 3; loop++) {
        const loopOffset = loop * 3.5;
        let noteTime = loopOffset;
        melody.forEach((m, idx) => {
          playNote(m.note, noteTime, 0.35, 'sine', 0.4, 4000);
          playNote(m.note === 'C6' ? 'C4' : 'A3', noteTime, 0.25, 'triangle', 0.2, 1000);
          if (idx % 2 === 0) playKick(noteTime);
          noteTime += m.d;
        });
      }
      break;
    }

    case 'nokia_retro': {
      // Iconic 8-bit Gran Vals style motif
      const nokiaNotes = [
        { n: 'E5', t: 0.0, d: 0.15 }, { n: 'D5', t: 0.18, d: 0.15 }, { n: 'F#4', t: 0.36, d: 0.3 }, { n: 'G#4', t: 0.72, d: 0.3 },
        { n: 'C#5', t: 1.08, d: 0.15 }, { n: 'B4', t: 1.26, d: 0.15 }, { n: 'D4', t: 1.44, d: 0.3 }, { n: 'E4', t: 1.80, d: 0.3 },
        { n: 'B4', t: 2.16, d: 0.15 }, { n: 'A4', t: 2.34, d: 0.15 }, { n: 'C#4', t: 2.52, d: 0.3 }, { n: 'E4', t: 2.88, d: 0.3 },
        { n: 'A4', t: 3.24, d: 0.6 }
      ];
      for (let loop = 0; loop < 3; loop++) {
        const loopOffset = loop * 4.0;
        nokiaNotes.forEach(item => {
          playNote(item.n, loopOffset + item.t, item.d, 'square', 0.28, 5000);
        });
      }
      break;
    }

    case 'zen_chime': {
      // Peaceful crystalline ambient chimes
      const chords = [
        ['C4', 'E4', 'G4', 'B4', 'E5'],
        ['A3', 'C4', 'E4', 'G4', 'C5'],
        ['F3', 'A3', 'C4', 'E4', 'A4'],
        ['G3', 'B3', 'D4', 'G4', 'D5'],
      ];
      chords.forEach((chord, cIdx) => {
        const cTime = cIdx * 2.8;
        chord.forEach((note, nIdx) => {
          playNote(note, cTime + nIdx * 0.12, 2.2, 'sine', 0.22, 2500);
        });
      });
      break;
    }

    case 'hyperdrive_alert': {
      // Punchy sci-fi riser notification
      for (let loop = 0; loop < 3; loop++) {
        const t = loop * 3.2;
        playNote('C5', t, 0.08, 'sawtooth', 0.3, 3000);
        playNote('G5', t + 0.1, 0.08, 'sawtooth', 0.35, 4000);
        playNote('C6', t + 0.2, 0.35, 'triangle', 0.4, 6000);
        playKick(t);
      }
      break;
    }

    case 'tokyo_phonk': {
      // Crisp 808 Phonk Cowbell
      const cowbellPattern = [
        { n: 'F#5', t: 0.0 }, { n: 'F#5', t: 0.25 }, { n: 'A5', t: 0.5 },
        { n: 'F#5', t: 0.75 }, { n: 'E5', t: 1.0 }, { n: 'D5', t: 1.25 },
        { n: 'C#5', t: 1.5 }, { n: 'E5', t: 1.75 }
      ];
      for (let loop = 0; loop < 4; loop++) {
        const loopOffset = loop * 2.2;
        cowbellPattern.forEach(p => {
          playNote(p.n, loopOffset + p.t, 0.15, 'triangle', 0.35, 4500);
        });
        playKick(loopOffset);
        playKick(loopOffset + 0.75);
        playHiHat(loopOffset + 0.25);
        playHiHat(loopOffset + 1.25);
      }
      break;
    }

    case 'pixel_quest': {
      // Fun arcade 8-bit game victory / ring chime
      const gamePattern = [
        { n: 'C4', t: 0.0, d: 0.1 }, { n: 'E4', t: 0.1, d: 0.1 }, { n: 'G4', t: 0.2, d: 0.1 },
        { n: 'C5', t: 0.3, d: 0.15 }, { n: 'E5', t: 0.45, d: 0.15 }, { n: 'G5', t: 0.6, d: 0.3 },
        { n: 'E5', t: 0.95, d: 0.15 }, { n: 'C6', t: 1.15, d: 0.5 }
      ];
      for (let loop = 0; loop < 3; loop++) {
        const loopOffset = loop * 3.0;
        gamePattern.forEach(p => {
          playNote(p.n, loopOffset + p.t, p.d, 'square', 0.25, 6000);
        });
      }
      break;
    }

    case 'minimal_pulse': {
      // Subtle elegant iOS style acoustic bell
      const pulseNotes = ['A4', 'E5', 'B5', 'C#6'];
      for (let loop = 0; loop < 4; loop++) {
        const loopOffset = loop * 2.5;
        pulseNotes.forEach((n, idx) => {
          playNote(n, loopOffset + idx * 0.14, 1.2, 'sine', 0.35, 3000);
        });
      }
      break;
    }

    case 'lofi_guitar': {
      // Warm soothing lo-fi jazzy electric piano
      const lofiChords = [
        ['D4', 'F#4', 'A4', 'C#5'],
        ['B3', 'D4', 'F#4', 'A4'],
        ['G3', 'B3', 'D4', 'F#4'],
        ['A3', 'C#4', 'E4', 'G4']
      ];
      lofiChords.forEach((chord, idx) => {
        const t = idx * 2.5;
        chord.forEach((note, nIdx) => {
          playNote(note, t + nIdx * 0.06, 2.0, 'sine', 0.28, 1800);
        });
      });
      break;
    }

    case 'cinematic_horn': {
      // Brass horn crescendo
      for (let loop = 0; loop < 2; loop++) {
        const t = loop * 5.0;
        playNote('D3', t, 2.5, 'sawtooth', 0.35, 1000);
        playNote('A3', t + 0.4, 2.3, 'sawtooth', 0.35, 1200);
        playNote('D4', t + 0.8, 2.5, 'sawtooth', 0.4, 1600);
        playNote('F#4', t + 1.2, 2.2, 'sawtooth', 0.45, 2000);
        playKick(t);
        playKick(t + 2.0);
      }
      break;
    }

    case 'iphone_remix': {
      // Shimmering crystalline marimba remix
      const notes = ['G5', 'A5', 'B5', 'D6', 'E6', 'D6', 'B5', 'A5', 'G5'];
      for (let loop = 0; loop < 3; loop++) {
        const loopOffset = loop * 3.2;
        notes.forEach((n, idx) => {
          playNote(n, loopOffset + idx * 0.18, 0.4, 'triangle', 0.35, 4000);
          if (idx % 2 === 0) playKick(loopOffset + idx * 0.36);
        });
      }
      break;
    }

    default: {
      // Default melodious chime
      const defaultNotes = ['C4', 'E4', 'G4', 'C5', 'E5', 'G5'];
      for (let loop = 0; loop < 3; loop++) {
        const loopOffset = loop * 3.0;
        defaultNotes.forEach((n, idx) => {
          playNote(n, loopOffset + idx * 0.2, 0.6, 'sine', 0.3, 3000);
        });
      }
      break;
    }
  }

  return await offlineCtx.startRendering();
}

// Active single audio playback manager for global player
class RingtonePlayerManager {
  private ctx: AudioContext | null = null;
  private currentSource: AudioBufferSourceNode | null = null;
  private currentHtmlAudio: HTMLAudioElement | null = null;
  private gainNode: GainNode | null = null;
  private cachedBuffers: Map<string, AudioBuffer> = new Map();
  private startTime: number = 0;
  private pauseOffset: number = 0;
  private isPlaying: boolean = false;
  private currentId: string | null = null;
  private onTimeUpdateCallback: ((currentTime: number) => void) | null = null;
  private onEndCallback: (() => void) | null = null;
  private progressInterval: number | null = null;
  private isLooping: boolean = false;
  private volume: number = 0.8;

  constructor() {
    // Lazy init
  }

  public setCallbacks(onTimeUpdate: (t: number) => void, onEnd: () => void) {
    this.onTimeUpdateCallback = onTimeUpdate;
    this.onEndCallback = onEnd;
  }

  public setLoop(loop: boolean) {
    this.isLooping = loop;
    if (this.currentSource) {
      this.currentSource.loop = loop;
    }
    if (this.currentHtmlAudio) {
      this.currentHtmlAudio.loop = loop;
    }
  }

  public setVolume(vol: number) {
    this.volume = Math.max(0, Math.min(1, vol));
    if (this.gainNode) {
      this.gainNode.gain.setValueAtTime(this.volume, this.ctx?.currentTime || 0);
    }
    if (this.currentHtmlAudio) {
      this.currentHtmlAudio.volume = this.volume;
    }
  }

  public async playRingtone(
    id: string,
    preset?: string,
    blobUrl?: string,
    seekTime: number = 0
  ): Promise<void> {
    this.stop();
    this.ctx = getAudioContext();
    this.currentId = id;

    if (blobUrl) {
      // HTML5 audio playback for custom uploaded files
      this.currentHtmlAudio = new Audio(blobUrl);
      this.currentHtmlAudio.volume = this.volume;
      this.currentHtmlAudio.loop = this.isLooping;
      this.currentHtmlAudio.currentTime = seekTime;

      this.currentHtmlAudio.ontimeupdate = () => {
        if (this.currentHtmlAudio && this.onTimeUpdateCallback) {
          this.onTimeUpdateCallback(this.currentHtmlAudio.currentTime);
        }
      };

      this.currentHtmlAudio.onended = () => {
        if (!this.isLooping) {
          this.isPlaying = false;
          if (this.onEndCallback) this.onEndCallback();
        }
      };

      await this.currentHtmlAudio.play();
      this.isPlaying = true;
      return;
    }

    // Synth Preset Playback via AudioBuffer
    let buffer: AudioBuffer;
    const cacheKey = preset || 'default';
    if (this.cachedBuffers.has(cacheKey)) {
      buffer = this.cachedBuffers.get(cacheKey)!;
    } else {
      buffer = await renderPresetAudioBuffer(cacheKey);
      this.cachedBuffers.set(cacheKey, buffer);
    }

    this.gainNode = this.ctx.createGain();
    this.gainNode.gain.setValueAtTime(this.volume, this.ctx.currentTime);
    this.gainNode.connect(this.ctx.destination);

    this.currentSource = this.ctx.createBufferSource();
    this.currentSource.buffer = buffer;
    this.currentSource.loop = this.isLooping;
    this.currentSource.connect(this.gainNode);

    const offset = Math.min(seekTime, buffer.duration);
    this.startTime = this.ctx.currentTime - offset;
    this.pauseOffset = offset;

    this.currentSource.onended = () => {
      if (!this.isLooping && this.isPlaying) {
        this.isPlaying = false;
        this.stopProgressLoop();
        if (this.onEndCallback) this.onEndCallback();
      }
    };

    this.currentSource.start(0, offset);
    this.isPlaying = true;
    this.startProgressLoop(buffer.duration);
  }

  public pause(): void {
    if (this.currentHtmlAudio) {
      this.currentHtmlAudio.pause();
      this.isPlaying = false;
      return;
    }

    if (this.currentSource && this.ctx) {
      this.pauseOffset = this.ctx.currentTime - this.startTime;
      this.currentSource.stop();
      this.currentSource.disconnect();
      this.currentSource = null;
      this.isPlaying = false;
      this.stopProgressLoop();
    }
  }

  public stop(): void {
    if (this.currentHtmlAudio) {
      this.currentHtmlAudio.pause();
      this.currentHtmlAudio.currentTime = 0;
      this.currentHtmlAudio = null;
    }
    if (this.currentSource) {
      try {
        this.currentSource.stop();
        this.currentSource.disconnect();
      } catch {
        // Ignore already stopped
      }
      this.currentSource = null;
    }
    this.isPlaying = false;
    this.pauseOffset = 0;
    this.stopProgressLoop();
  }

  private startProgressLoop(duration: number) {
    this.stopProgressLoop();
    this.progressInterval = window.setInterval(() => {
      if (this.ctx && this.isPlaying && this.onTimeUpdateCallback) {
        let cur = (this.ctx.currentTime - this.startTime);
        if (this.isLooping) {
          cur = cur % duration;
        } else if (cur >= duration) {
          cur = duration;
        }
        this.onTimeUpdateCallback(cur);
      }
    }, 50);
  }

  private stopProgressLoop() {
    if (this.progressInterval !== null) {
      clearInterval(this.progressInterval);
      this.progressInterval = null;
    }
  }
}

export const globalAudioPlayer = new RingtonePlayerManager();

// Extract waveform bars (40 normalized amplitude bars) from an uploaded Audio File
export async function extractWaveformDataFromFile(file: File): Promise<{ waveform: number[]; duration: number }> {
  const ctx = getAudioContext();
  const arrayBuffer = await file.arrayBuffer();
  const audioBuffer = await ctx.decodeAudioData(arrayBuffer);

  const rawData = audioBuffer.getChannelData(0);
  const totalSamples = rawData.length;
  const numBars = 40;
  const blockSize = Math.floor(totalSamples / numBars);
  const waveform: number[] = [];

  for (let i = 0; i < numBars; i++) {
    const blockStart = blockSize * i;
    let sum = 0;
    for (let j = 0; j < blockSize; j++) {
      sum += Math.abs(rawData[blockStart + j] || 0);
    }
    const avg = sum / blockSize;
    waveform.push(Math.max(0.12, Math.min(1.0, avg * 3.5)));
  }

  return {
    waveform,
    duration: Math.round(audioBuffer.duration * 10) / 10
  };
}

// Download ringtone as real audio file (WAV)
export async function triggerRingtoneDownload(
  title: string,
  preset?: string,
  audioBlobUrl?: string
): Promise<void> {
  const safeFilename = `${title.replace(/[^a-zA-Z0-9_-]/g, '_')}_Ringtone.wav`;

  if (audioBlobUrl) {
    // If it's a blob url from upload
    const a = document.createElement('a');
    a.href = audioBlobUrl;
    a.download = safeFilename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    return;
  }

  // Generate WAV blob from preset
  const buffer = await renderPresetAudioBuffer(preset || 'default');
  const blob = bufferToWaveBlob(buffer);
  const url = URL.createObjectURL(blob);

  const a = document.createElement('a');
  a.href = url;
  a.download = safeFilename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);

  setTimeout(() => URL.revokeObjectURL(url), 10000);
}
