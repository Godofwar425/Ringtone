export type RingtoneCategory = 
  | 'all'
  | 'ios'
  | 'retro'
  | 'synthwave'
  | 'marimba'
  | 'lofi'
  | 'alerts'
  | 'classical'
  | 'phonk'
  | 'gaming'
  | 'cinematic'
  | 'nature';

export type ToneType = 'call' | 'notification' | 'alarm';

export type SortFilter = 'trending' | 'popular' | 'most_liked' | 'newest' | 'downloads';

export interface Ringtone {
  id: string;
  title: string;
  artist: string;
  category: RingtoneCategory;
  type: ToneType;
  duration: number; // in seconds
  likes: number;
  dislikes: number;
  downloads: number;
  createdAt: string;
  tags: string[];
  waveformData: number[]; // 0.0 to 1.0 bars
  synthPreset?: string; // identifier for web audio synth generator
  audioBlobUrl?: string; // for user uploaded files
  fileSizeKb: number;
  featured?: boolean;
}

export interface UserRatingState {
  [ringtoneId: string]: 'like' | 'dislike' | 'none';
}

export interface AudioPlaybackState {
  currentRingtoneId: string | null;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  isMuted: boolean;
  isLooping: boolean;
}
