import React from 'react';
import { 
  Play, 
  Pause, 
  Download, 
  ThumbsUp, 
  ThumbsDown, 
  Repeat, 
  Volume2, 
  VolumeX, 
  X, 
  SkipBack, 
  SkipForward,
  Music2
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Ringtone, AudioPlaybackState } from '../types';

interface StickyAudioPlayerProps {
  currentRingtone: Ringtone | null;
  playbackState: AudioPlaybackState;
  onTogglePlay: () => void;
  onSeek: (seconds: number) => void;
  onToggleLoop: () => void;
  onVolumeChange: (vol: number) => void;
  onToggleMute: () => void;
  onPrevious: () => void;
  onNext: () => void;
  onClose: () => void;
  userRating: 'like' | 'dislike' | 'none';
  onVote: (ringtoneId: string, type: 'like' | 'dislike') => void;
  onDownload: (ringtone: Ringtone) => void;
  onOpenDetails: (ringtone: Ringtone) => void;
}

export const StickyAudioPlayer: React.FC<StickyAudioPlayerProps> = ({
  currentRingtone,
  playbackState,
  onTogglePlay,
  onSeek,
  onToggleLoop,
  onVolumeChange,
  onToggleMute,
  onPrevious,
  onNext,
  onClose,
  userRating,
  onVote,
  onDownload,
  onOpenDetails,
}) => {
  if (!currentRingtone) return null;

  const progressPercent = currentRingtone.duration > 0
    ? (playbackState.currentTime / currentRingtone.duration) * 100
    : 0;

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  const handleDownloadClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
    const x = (rect.left + rect.width / 2) / window.innerWidth;
    const y = (rect.top + rect.height / 2) / window.innerHeight;
    confetti({
      particleCount: 40,
      spread: 60,
      origin: { x, y },
      colors: ['#8b5cf6', '#6366f1', '#06b6d4', '#10b981'],
    });
    onDownload(currentRingtone);
  };

  return (
    <div
      id="sticky-audio-player"
      className="fixed bottom-0 inset-x-0 z-40 bg-white/95 backdrop-blur-xl border-t border-slate-200 shadow-2xl text-slate-800 transition-all duration-300"
    >
      {/* Progress Bar (Clickable top edge for quick seek) */}
      <div
        id="player-progress-bar-track"
        onClick={(e) => {
          const rect = e.currentTarget.getBoundingClientRect();
          const clickX = e.clientX - rect.left;
          const ratio = Math.max(0, Math.min(1, clickX / rect.width));
          onSeek(ratio * currentRingtone.duration);
        }}
        className="w-full h-1.5 bg-slate-200 hover:h-2.5 transition-all cursor-pointer relative group/bar"
      >
        <div
          style={{ width: `${Math.min(100, Math.max(0, progressPercent))}%` }}
          className="h-full bg-blue-600 relative transition-all duration-75"
        >
          <div className="absolute right-0 top-1/2 -translate-y-1/2 w-3 h-3 bg-white border-2 border-blue-600 rounded-full shadow-md scale-0 group-hover/bar:scale-100 transition-transform" />
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex flex-wrap items-center justify-between gap-3 sm:gap-6">
        {/* Left: Track Information & Metadata */}
        <div className="flex items-center gap-3 min-w-[200px] flex-1 sm:flex-none">
          <div 
            onClick={() => onOpenDetails(currentRingtone)}
            className="w-10 h-10 rounded-lg bg-blue-50 border border-blue-200/80 flex items-center justify-center text-blue-600 shrink-0 cursor-pointer group hover:bg-blue-600 hover:text-white transition-colors shadow-2xs"
          >
            <Music2 className="w-5 h-5 group-hover:scale-110 transition-transform" />
          </div>
          <div className="min-w-0">
            <h4
              onClick={() => onOpenDetails(currentRingtone)}
              className="font-bold text-sm text-slate-900 truncate hover:text-blue-600 transition-colors cursor-pointer"
            >
              {currentRingtone.title}
            </h4>
            <p className="text-xs text-slate-500 truncate">
              {currentRingtone.artist} • <span className="capitalize">{currentRingtone.category}</span>
            </p>
          </div>

          {/* Player Quick Like / Dislike */}
          <div className="hidden md:flex items-center bg-slate-100 p-0.5 rounded-lg border border-slate-200 ml-2">
            <button
              id="player-like-btn"
              onClick={() => onVote(currentRingtone.id, 'like')}
              className={`p-1.5 rounded-l text-xs font-semibold cursor-pointer border-r border-slate-200 transition-colors ${
                userRating === 'like'
                  ? 'text-blue-700 bg-blue-100'
                  : 'text-slate-600 hover:text-blue-600'
              }`}
              title="Like"
            >
              <ThumbsUp className={`w-3.5 h-3.5 ${userRating === 'like' ? 'fill-current' : ''}`} />
            </button>
            <button
              id="player-dislike-btn"
              onClick={() => onVote(currentRingtone.id, 'dislike')}
              className={`p-1.5 rounded-r text-xs font-semibold cursor-pointer transition-colors ${
                userRating === 'dislike'
                  ? 'text-rose-700 bg-rose-100'
                  : 'text-slate-600 hover:text-rose-600'
              }`}
              title="Dislike"
            >
              <ThumbsDown className={`w-3.5 h-3.5 ${userRating === 'dislike' ? 'fill-current' : ''}`} />
            </button>
          </div>
        </div>

        {/* Center: Controls (Prev, Play/Pause, Next, Loop, Time) */}
        <div className="flex flex-col items-center gap-1 order-3 sm:order-2 w-full sm:w-auto">
          <div className="flex items-center gap-3 sm:gap-4">
            <button
              id="player-prev-btn"
              onClick={onPrevious}
              className="p-1.5 text-slate-500 hover:text-slate-900 rounded-md transition-colors cursor-pointer"
              title="Previous Ringtone"
            >
              <SkipBack className="w-4 h-4" />
            </button>

            <button
              id="player-play-btn"
              onClick={onTogglePlay}
              className="w-10 h-10 rounded-full bg-blue-600 text-white flex items-center justify-center shadow-xs hover:bg-blue-700 hover:scale-105 active:scale-95 transition-all cursor-pointer"
              aria-label={playbackState.isPlaying ? 'Pause' : 'Play'}
            >
              {playbackState.isPlaying ? (
                <Pause className="w-5 h-5 fill-current" />
              ) : (
                <Play className="w-5 h-5 fill-current ml-0.5" />
              )}
            </button>

            <button
              id="player-next-btn"
              onClick={onNext}
              className="p-1.5 text-slate-500 hover:text-slate-900 rounded-md transition-colors cursor-pointer"
              title="Next Ringtone"
            >
              <SkipForward className="w-4 h-4" />
            </button>

            <button
              id="player-loop-btn"
              onClick={onToggleLoop}
              className={`p-1.5 rounded-md transition-colors cursor-pointer ${
                playbackState.isLooping
                  ? 'text-blue-700 bg-blue-100'
                  : 'text-slate-400 hover:text-slate-700'
              }`}
              title={playbackState.isLooping ? 'Looping enabled' : 'Loop disabled'}
            >
              <Repeat className="w-4 h-4" />
            </button>
          </div>

          <div className="flex items-center gap-2 text-[11px] font-mono text-slate-500">
            <span>{formatTime(playbackState.currentTime)}</span>
            <span>/</span>
            <span>{formatTime(currentRingtone.duration)}</span>
          </div>
        </div>

        {/* Right: Volume & Download Button & Close */}
        <div className="flex items-center gap-3 order-2 sm:order-3">
          {/* Volume Slider */}
          <div className="hidden lg:flex items-center gap-2 bg-slate-100 px-3 py-1.5 rounded-lg border border-slate-200">
            <button
              id="player-mute-btn"
              onClick={onToggleMute}
              className="text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
              title={playbackState.isMuted ? 'Unmute' : 'Mute'}
            >
              {playbackState.isMuted || playbackState.volume === 0 ? (
                <VolumeX className="w-4 h-4 text-rose-500" />
              ) : (
                <Volume2 className="w-4 h-4" />
              )}
            </button>
            <input
              id="player-volume-slider"
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={playbackState.isMuted ? 0 : playbackState.volume}
              onChange={(e) => onVolumeChange(parseFloat(e.target.value))}
              className="w-20 accent-blue-600 h-1.5 bg-slate-200 rounded-lg cursor-pointer"
            />
          </div>

          {/* Download Button */}
          <button
            id="player-download-btn"
            onClick={handleDownloadClick}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-md text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 active:scale-98 shadow-xs transition-all cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>Download</span>
          </button>

          {/* Close Player */}
          <button
            id="player-close-btn"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-md transition-colors cursor-pointer"
            title="Close Player"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
