import React, { useState } from 'react';
import { 
  X, 
  Smartphone, 
  Apple, 
  CheckCircle2, 
  Download, 
  FolderCheck, 
  Settings, 
  Music,
  Share2
} from 'lucide-react';

interface HowToSetModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const HowToSetModal: React.FC<HowToSetModalProps> = ({ isOpen, onClose }) => {
  const [activePlatform, setActivePlatform] = useState<'android' | 'ios'>('android');

  if (!isOpen) return null;

  return (
    <div
      id="how-to-set-modal-overlay"
      className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto"
      onClick={onClose}
    >
      <div
        id="how-to-set-modal-container"
        className="bg-white border border-slate-200 rounded-2xl w-full max-w-xl overflow-hidden shadow-2xl relative my-8 text-slate-800"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50/80">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-50 border border-blue-200/80 flex items-center justify-center text-blue-600">
              <Smartphone className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-bold text-lg text-slate-900">How to Set Your Ringtone</h2>
              <p className="text-xs text-slate-500">Step-by-step guide for Android & iPhone</p>
            </div>
          </div>
          <button
            id="close-how-to-set-btn"
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-md transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Platform Switcher */}
        <div className="p-6 pb-2">
          <div className="flex bg-slate-100 p-1 rounded-lg border border-slate-200 text-xs font-semibold">
            <button
              id="guide-tab-android"
              onClick={() => setActivePlatform('android')}
              className={`flex-1 py-2 rounded-md flex items-center justify-center gap-2 transition-all cursor-pointer ${
                activePlatform === 'android'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Smartphone className="w-4 h-4" />
              <span>Android Guide</span>
            </button>
            <button
              id="guide-tab-ios"
              onClick={() => setActivePlatform('ios')}
              className={`flex-1 py-2 rounded-md flex items-center justify-center gap-2 transition-all cursor-pointer ${
                activePlatform === 'ios'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Apple className="w-4 h-4" />
              <span>iPhone / iOS Guide</span>
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 pt-3 space-y-4">
          {activePlatform === 'android' ? (
            <div className="space-y-3">
              <div className="flex items-start gap-3 p-3 bg-slate-50 rounded-xl border border-slate-200">
                <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
                  1
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900">Download Ringtone File</h4>
                  <p className="text-xs text-slate-600 mt-0.5">
                    Click the "Download" button on any tone. The audio file (.wav / .mp3) saves directly to your device's <b>Downloads</b> folder.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3 bg-slate-50 rounded-xl border border-slate-200">
                <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
                  2
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900">Open Settings &gt; Sound & Vibration</h4>
                  <p className="text-xs text-slate-600 mt-0.5">
                    Navigate to your phone's <b>Settings</b> &rarr; tap <b>Sound & Vibration</b> &rarr; select <b>Phone Ringtone</b> or <b>Notification Sound</b>.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3 bg-slate-50 rounded-xl border border-slate-200">
                <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
                  3
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900">Choose "Custom Ringtone" or "+"</h4>
                  <p className="text-xs text-slate-600 mt-0.5">
                    Tap <b>Add Ringtone (+)</b> or <b>Custom Ringtone</b> and select the downloaded file from your storage. Done!
                  </p>
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="flex items-start gap-3 p-3 bg-slate-50 rounded-xl border border-slate-200">
                <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
                  1
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900">Download Tone to iPhone Files</h4>
                  <p className="text-xs text-slate-600 mt-0.5">
                    Tap "Download" on your iPhone Safari/Chrome to save the file into the <b>Files app</b>.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3 bg-slate-50 rounded-xl border border-slate-200">
                <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
                  2
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900">Set via Free GarageBand App (No Computer Needed)</h4>
                  <p className="text-xs text-slate-600 mt-0.5">
                    Open Apple's free <b>GarageBand</b> app &rarr; Audio Recorder &rarr; tap the Loops icon &rarr; select Files &rarr; drag the downloaded tone into the track &rarr; Tap "My Songs" &rarr; Long press song &rarr; <b>Share &rarr; Ringtone</b>.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3 bg-slate-50 rounded-xl border border-slate-200">
                <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
                  3
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900">Or Sync via Mac / PC iTunes</h4>
                  <p className="text-xs text-slate-600 mt-0.5">
                    Drag the downloaded file into Apple Music / iTunes or Finder Tones sync.
                  </p>
                </div>
              </div>
            </div>
          )}

          <div className="pt-3 border-t border-slate-200 flex justify-end">
            <button
              id="guide-got-it-btn"
              onClick={onClose}
              className="px-5 py-2 rounded-md text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 shadow-xs transition-colors cursor-pointer"
            >
              Got it!
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
