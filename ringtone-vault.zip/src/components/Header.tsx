import React from 'react';
import { 
  Search, 
  Upload, 
  Sparkles, 
  SlidersHorizontal, 
  LayoutGrid, 
  List, 
  Smartphone,
  PhoneCall,
  BellRing,
  AlarmClock,
  X
} from 'lucide-react';
import { SortFilter, ToneType } from '../types';

interface HeaderProps {
  searchQuery: string;
  onSearchChange: (q: string) => void;
  selectedToneType: ToneType | 'all';
  onSelectToneType: (type: ToneType | 'all') => void;
  sortFilter: SortFilter;
  onSortChange: (sort: SortFilter) => void;
  viewMode: 'grid' | 'list';
  onViewModeChange: (mode: 'grid' | 'list') => void;
  onOpenUpload: () => void;
  onOpenHowToSet: () => void;
  totalTonesCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  searchQuery,
  onSearchChange,
  selectedToneType,
  onSelectToneType,
  sortFilter,
  onSortChange,
  viewMode,
  onViewModeChange,
  onOpenUpload,
  onOpenHowToSet,
  totalTonesCount,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top Navbar */}
        <div className="flex items-center justify-between h-16 gap-3 sm:gap-6">
          {/* Logo & Brand */}
          <div className="flex items-center gap-3 shrink-0">
            <div id="brand-logo" className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center shadow-xs">
              <span className="text-white font-bold text-lg leading-none">Z</span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-lg tracking-tight text-slate-900 flex items-center gap-1">
                  TONE<span className="text-blue-600">BASE</span>
                </span>
                <span className="hidden sm:inline-block px-2 py-0.5 text-[11px] font-semibold bg-blue-50 text-blue-700 border border-blue-200/60 rounded-md">
                  Pro Audio
                </span>
              </div>
              <p className="hidden md:block text-[11px] text-slate-500 font-medium -mt-0.5">
                Free High-Quality Audio Tones & Sound Alerts
              </p>
            </div>
          </div>

          {/* Search Bar */}
          <div className="flex-1 max-w-lg relative">
            <div className="relative">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
              <input
                id="search-ringtones-input"
                type="text"
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                placeholder="Search ringtones, alerts, and sound effects..."
                className="w-full bg-slate-100 text-slate-800 text-sm pl-10 pr-10 py-2 rounded-full border border-transparent focus:border-blue-500 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all placeholder:text-slate-400"
              />
              {searchQuery && (
                <button
                  id="clear-search-button"
                  onClick={() => onSearchChange('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-0.5 rounded-full"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            <button
              id="how-to-set-button"
              onClick={onOpenHowToSet}
              className="hidden lg:flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200/80 border border-slate-200 rounded-md transition-colors cursor-pointer"
            >
              <Smartphone className="w-4 h-4 text-blue-600" />
              <span>How to Set Tone</span>
            </button>

            <button
              id="upload-ringtone-button"
              onClick={onOpenUpload}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs sm:text-sm font-semibold rounded-md transition-colors flex items-center space-x-2 shadow-xs cursor-pointer active:scale-98"
            >
              <Upload className="w-4 h-4" />
              <span>Upload</span>
            </button>
          </div>
        </div>

        {/* Secondary Subheader Toolbar: Tone Types, Sort & View Controls */}
        <div className="py-2.5 flex flex-wrap items-center justify-between gap-3 border-t border-slate-100 text-xs">
          {/* Tone Type Selector Tabs */}
          <div className="flex items-center gap-1 bg-slate-100/80 p-1 rounded-lg border border-slate-200/60">
            <button
              id="tone-filter-all"
              onClick={() => onSelectToneType('all')}
              className={`px-3 py-1.5 rounded-md font-semibold transition-colors flex items-center gap-1.5 cursor-pointer ${
                selectedToneType === 'all'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>All Tones</span>
              <span className={`text-[10px] ml-0.5 ${selectedToneType === 'all' ? 'text-blue-100' : 'text-slate-400'}`}>
                ({totalTonesCount})
              </span>
            </button>
            <button
              id="tone-filter-calls"
              onClick={() => onSelectToneType('call')}
              className={`px-3 py-1.5 rounded-md font-semibold transition-colors flex items-center gap-1.5 cursor-pointer ${
                selectedToneType === 'call'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
              }`}
            >
              <PhoneCall className="w-3.5 h-3.5" />
              <span>Calls</span>
            </button>
            <button
              id="tone-filter-alerts"
              onClick={() => onSelectToneType('notification')}
              className={`px-3 py-1.5 rounded-md font-semibold transition-colors flex items-center gap-1.5 cursor-pointer ${
                selectedToneType === 'notification'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
              }`}
            >
              <BellRing className="w-3.5 h-3.5" />
              <span>Alerts / SMS</span>
            </button>
            <button
              id="tone-filter-alarms"
              onClick={() => onSelectToneType('alarm')}
              className={`px-3 py-1.5 rounded-md font-semibold transition-colors flex items-center gap-1.5 cursor-pointer ${
                selectedToneType === 'alarm'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
              }`}
            >
              <AlarmClock className="w-3.5 h-3.5" />
              <span>Alarms</span>
            </button>
          </div>

          {/* Right Controls: Sort & Grid/List view */}
          <div className="flex items-center gap-3">
            {/* Sort Filter Dropdown */}
            <div className="flex items-center gap-1.5">
              <SlidersHorizontal className="w-3.5 h-3.5 text-slate-500" />
              <span className="text-slate-600 hidden sm:inline font-medium">Sort:</span>
              <select
                id="sort-ringtones-select"
                value={sortFilter}
                onChange={(e) => onSortChange(e.target.value as SortFilter)}
                className="bg-white text-slate-800 font-medium px-2.5 py-1.5 rounded-md border border-slate-200 text-xs focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 cursor-pointer shadow-2xs"
              >
                <option value="trending">🔥 Trending Now</option>
                <option value="popular">⭐ Most Downloaded</option>
                <option value="most_liked">👍 Most Liked</option>
                <option value="newest">✨ Newest Releases</option>
              </select>
            </div>

            {/* View Mode Toggle */}
            <div className="flex items-center bg-slate-100 p-0.5 rounded-md border border-slate-200">
              <button
                id="view-mode-grid"
                onClick={() => onViewModeChange('grid')}
                className={`p-1.5 rounded transition-colors cursor-pointer ${
                  viewMode === 'grid'
                    ? 'bg-white text-blue-600 shadow-2xs'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
                title="Grid View"
              >
                <LayoutGrid className="w-4 h-4" />
              </button>
              <button
                id="view-mode-list"
                onClick={() => onViewModeChange('list')}
                className={`p-1.5 rounded transition-colors cursor-pointer ${
                  viewMode === 'list'
                    ? 'bg-white text-blue-600 shadow-2xs'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
                title="List View"
              >
                <List className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
