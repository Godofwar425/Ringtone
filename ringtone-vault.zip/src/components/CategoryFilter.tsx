import React from 'react';
import { 
  Compass, 
  Smartphone, 
  Zap, 
  Music, 
  Gamepad2, 
  Volume2, 
  Coffee, 
  BellRing, 
  Sparkles, 
  Film, 
  Radio, 
  Sun,
  ChevronRight,
  ChevronLeft
} from 'lucide-react';
import { RingtoneCategory } from '../types';
import { CATEGORIES } from '../data/initialRingtones';

interface CategoryFilterProps {
  activeCategory: RingtoneCategory;
  onSelectCategory: (cat: RingtoneCategory) => void;
  categoryCounts: Record<string, number>;
}

const getCategoryIcon = (iconName: string) => {
  switch (iconName) {
    case 'Compass': return <Compass className="w-4 h-4" />;
    case 'Smartphone': return <Smartphone className="w-4 h-4" />;
    case 'Zap': return <Zap className="w-4 h-4" />;
    case 'Music': return <Music className="w-4 h-4" />;
    case 'Gamepad2': return <Gamepad2 className="w-4 h-4" />;
    case 'Volume2': return <Volume2 className="w-4 h-4" />;
    case 'Coffee': return <Coffee className="w-4 h-4" />;
    case 'BellRing': return <BellRing className="w-4 h-4" />;
    case 'Sparkles': return <Sparkles className="w-4 h-4" />;
    case 'Film': return <Film className="w-4 h-4" />;
    case 'Radio': return <Radio className="w-4 h-4" />;
    case 'Sun': return <Sun className="w-4 h-4" />;
    default: return <Music className="w-4 h-4" />;
  }
};

export const CategoryFilter: React.FC<CategoryFilterProps> = ({
  activeCategory,
  onSelectCategory,
  categoryCounts,
}) => {
  const scrollContainerRef = React.useRef<HTMLDivElement>(null);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollContainerRef.current) {
      const scrollAmount = direction === 'left' ? -250 : 250;
      scrollContainerRef.current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
  };

  return (
    <div className="relative group my-4">
      {/* Scroll Left Button */}
      <button
        id="category-scroll-left"
        onClick={() => scroll('left')}
        className="hidden md:flex absolute -left-3 top-1/2 -translate-y-1/2 z-10 w-7 h-7 bg-white text-slate-600 border border-slate-200 rounded-full items-center justify-center shadow-md hover:bg-slate-50 hover:text-slate-900 transition-all cursor-pointer"
        aria-label="Scroll categories left"
      >
        <ChevronLeft className="w-4 h-4" />
      </button>

      {/* Horizontal Pills Container */}
      <div
        ref={scrollContainerRef}
        className="flex items-center gap-2 overflow-x-auto scrollbar-none py-1 px-1 scroll-smooth"
        style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
      >
        {CATEGORIES.map((cat) => {
          const isActive = activeCategory === cat.id;
          const count = cat.id === 'all' 
            ? Object.values(categoryCounts).reduce<number>((a, b) => a + Number(b), 0)
            : (categoryCounts[cat.id] || 0);

          return (
            <button
              key={cat.id}
              id={`category-pill-${cat.id}`}
              onClick={() => onSelectCategory(cat.id)}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all duration-150 shrink-0 cursor-pointer border ${
                isActive
                  ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                  : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50 hover:text-blue-600 hover:border-blue-200 shadow-2xs'
              }`}
            >
              <span className={isActive ? 'text-white' : 'text-blue-600'}>
                {getCategoryIcon(cat.iconName)}
              </span>
              <span>{cat.label}</span>
              <span
                className={`text-[10px] px-1.5 py-0.5 rounded-full font-mono ${
                  isActive
                    ? 'bg-blue-700 text-white'
                    : 'bg-slate-100 text-slate-500'
                }`}
              >
                {count}
              </span>
            </button>
          );
        })}
      </div>

      {/* Scroll Right Button */}
      <button
        id="category-scroll-right"
        onClick={() => scroll('right')}
        className="hidden md:flex absolute -right-3 top-1/2 -translate-y-1/2 z-10 w-7 h-7 bg-white text-slate-600 border border-slate-200 rounded-full items-center justify-center shadow-md hover:bg-slate-50 hover:text-slate-900 transition-all cursor-pointer"
        aria-label="Scroll categories right"
      >
        <ChevronRight className="w-4 h-4" />
      </button>
    </div>
  );
};
