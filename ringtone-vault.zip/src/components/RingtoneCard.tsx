import React from 'react';
import { 
  Play, 
  Pause, 
  Download, 
  ThumbsUp, 
  ThumbsDown, 
  Share2, 
  Info, 
  Sparkles,
  PhoneCall,
  BellRing,
  AlarmClock
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Ringtone, UserRatingState } from '../types';

interface RingtoneCardProps {
  ringtone: Ringtone;
  isPlaying: boolean;
  playbackProgress: number; // 0.0 to 1.0
  onTogglePlay: (ringtone: Ringtone) => void;
  onSeek: (ringtone: Ringtone, progressRatio: number) => void;
  userRating: 'like' | 'dislike' | 'none';
  onVote: (ringtoneId: string, type: 'like' | 'dislike') => void;
  onDownload: (ringtone: Ringtone) => void;
  onOpenDetails: (ringtone: Ringtone) => void;
}

export const RingtoneCard: React.FC<RingtoneCardProps> = ({
  ringtone,
  isPlaying,
  playbackProgress,
  onTogglePlay,
  onSeek,
  userRating,
  onVote,
  onDownload,
  onOpenDetails,
}) => {
  const [copied, setCopied] = React.useState(false);

  const handleShare = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(
      `${window.location.origin}?ringtone=${ringtone.id}#${encodeURIComponent(ringtone.title)}`
    );
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    // Confetti effect from button location
    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
    const x = (rect.left + rect.width / 2) / window.innerWidth;
    const y = (rect.top + rect.height / 2) / window.innerHeight;
    confetti({
      particleCount: 35,
      spread: 60,
      origin: { x, y },
      colors: ['#8b5cf6', '#6366f1', '#06b6d4', '#10b981'],
    });

    onDownload(ringtone);
  };

  const totalVotes = ringtone.likes + ringtone.dislikes;
  const likePercentage = totalVotes > 0 ? Math.round((ringtone.likes / totalVotes) * 100) : 100;

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  const getTypeIcon = () => {
    switch (ringtone.type) {
      case 'call': return <PhoneCall className="w-3 h-3 text-emerald-400" />;
      case 'notification': return <BellRing className="w-3 h-3 text-amber-400" />;
      case 'alarm': return <AlarmClock className="w-3 h-3 text-rose-400" />;
    }
  };

  return (
    <div
      id={`ringtone-card-${ringtone.id}`}
      className={`group relative bg-white border rounded-xl p-4 sm:p-5 transition-all duration-200 flex flex-col justify-between overflow-hidden shadow-xs hover:shadow-md hover:border-blue-300 ${
        isPlaying 
          ? 'border-blue-500 ring-2 ring-blue-500/20 bg-blue-50/15' 
          : 'border-slate-200'
      }`}
    >
      {/* Card Header: Type Badge, Category, and Action Buttons */}
      <div>
        <div className="flex items-center justify-between gap-2 mb-3">
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md text-[11px] font-semibold bg-slate-100 border border-slate-200 text-slate-700">
              {getTypeIcon()}
              <span className="capitalize">{ringtone.type} Tone</span>
            </span>
            <span className="text-[11px] font-medium px-2 py-0.5 rounded-md bg-blue-50 text-blue-700 border border-blue-200/60 capitalize">
              {ringtone.category}
            </span>
            {ringtone.featured && (
              <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-md bg-amber-50 text-amber-700 border border-amber-200">
                <Sparkles className="w-2.5 h-2.5" /> Featured
              </span>
            )}
          </div>

          <div className="flex items-center gap-1 text-slate-400">
            <button
              id={`share-btn-${ringtone.id}`}
              onClick={handleShare}
              className="p-1.5 hover:text-slate-700 hover:bg-slate-100 rounded-md transition-colors cursor-pointer"
              title={copied ? 'Copied link!' : 'Share ringtone link'}
            >
              <Share2 className="w-3.5 h-3.5" />
            </button>
            <button
              id={`info-btn-${ringtone.id}`}
              onClick={() => onOpenDetails(ringtone)}
              className="p-1.5 hover:text-slate-700 hover:bg-slate-100 rounded-md transition-colors cursor-pointer"
              title="Tone specs & how to set"
            >
              <Info className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Main Title & Artist */}
        <div className="mb-4">
          <h3 
            id={`ringtone-title-${ringtone.id}`}
            onClick={() => onOpenDetails(ringtone)}
            className="font-bold text-slate-900 text-base leading-snug tracking-tight hover:text-blue-600 transition-colors cursor-pointer line-clamp-1"
          >
            {ringtone.title}
          </h3>
          <p className="text-xs text-slate-500 font-medium mt-0.5 flex items-center justify-between">
            <span>By {ringtone.artist}</span>
            <span className="text-slate-400 font-mono text-[11px]">{formatDuration(ringtone.duration)}</span>
          </p>
        </div>

        {/* Audio Waveform & Big Play/Pause trigger */}
        <div className="relative bg-slate-50 border border-slate-200/80 rounded-xl p-3 mb-4 flex items-center gap-3">
          {/* Play/Pause Button */}
          <button
            id={`play-btn-${ringtone.id}`}
            onClick={() => onTogglePlay(ringtone)}
            className={`w-11 h-11 shrink-0 rounded-full flex items-center justify-center transition-all duration-200 cursor-pointer ${
              isPlaying
                ? 'bg-blue-600 text-white shadow-xs scale-102'
                : 'bg-blue-50 text-blue-600 hover:bg-blue-600 hover:text-white'
            }`}
            aria-label={isPlaying ? 'Pause ringtone' : 'Play ringtone'}
          >
            {isPlaying ? (
              <Pause className="w-5 h-5 fill-current" />
            ) : (
              <Play className="w-5 h-5 fill-current ml-0.5" />
            )}
          </button>

          {/* Interactive Waveform Display */}
          <div 
            id={`waveform-container-${ringtone.id}`}
            onClick={(e) => {
              const rect = e.currentTarget.getBoundingClientRect();
              const clickX = e.clientX - rect.left;
              const ratio = Math.max(0, Math.min(1, clickX / rect.width));
              onSeek(ringtone, ratio);
            }}
            className="flex-1 h-9 flex items-center justify-between gap-[2px] cursor-pointer py-1 group/wave relative select-none"
            title="Click to seek"
          >
            {ringtone.waveformData.map((val, idx) => {
              const barRatio = idx / ringtone.waveformData.length;
              const isPast = isPlaying && barRatio <= playbackProgress;
              const heightPct = Math.max(18, Math.round(val * 100));

              return (
                <div
                  key={idx}
                  className="flex-1 flex items-center justify-center h-full"
                >
                  <div
                    style={{ height: `${heightPct}%` }}
                    className={`w-full max-w-[4px] rounded-full transition-all duration-100 ${
                      isPast
                        ? 'bg-blue-600'
                        : 'bg-slate-300 group-hover/wave:bg-slate-400'
                    }`}
                  />
                </div>
              );
            })}
          </div>
        </div>

        {/* Tags */}
        <div className="flex flex-wrap gap-1.5 mb-4">
          {ringtone.tags.slice(0, 3).map((tag, tIdx) => (
            <span
              key={tIdx}
              className="text-[10px] text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md border border-slate-200/60 font-medium"
            >
              #{tag}
            </span>
          ))}
        </div>
      </div>

      {/* Card Footer: Like & Dislike Buttons + Download Button */}
      <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
        {/* Like & Dislike Group */}
        <div className="flex bg-slate-50 rounded-lg p-1 border border-slate-200">
          {/* Like Button */}
          <button
            id={`like-btn-${ringtone.id}`}
            onClick={(e) => {
              e.stopPropagation();
              onVote(ringtone.id, 'like');
            }}
            className={`px-2 py-1 flex items-center space-x-1 border-r border-slate-200 text-xs font-semibold rounded-l transition-colors cursor-pointer ${
              userRating === 'like'
                ? 'bg-blue-100 text-blue-700'
                : 'text-slate-600 hover:text-blue-600'
            }`}
            title="Like this ringtone"
          >
            <ThumbsUp className={`w-3.5 h-3.5 ${userRating === 'like' ? 'fill-current' : ''}`} />
            <span className="text-[10px] font-bold">{ringtone.likes >= 1000 ? `${(ringtone.likes / 1000).toFixed(1)}k` : ringtone.likes}</span>
          </button>

          {/* Dislike Button */}
          <button
            id={`dislike-btn-${ringtone.id}`}
            onClick={(e) => {
              e.stopPropagation();
              onVote(ringtone.id, 'dislike');
            }}
            className={`px-2 py-1 flex items-center space-x-1 text-xs font-semibold rounded-r transition-colors cursor-pointer ${
              userRating === 'dislike'
                ? 'bg-rose-100 text-rose-700'
                : 'text-slate-600 hover:text-rose-600'
            }`}
            title="Dislike this ringtone"
          >
            <ThumbsDown className={`w-3.5 h-3.5 ${userRating === 'dislike' ? 'fill-current' : ''}`} />
            <span className="text-[10px] font-bold">{ringtone.dislikes >= 1000 ? `${(ringtone.dislikes / 1000).toFixed(1)}k` : ringtone.dislikes}</span>
          </button>
        </div>

        {/* Download Button */}
        <button
          id={`download-btn-${ringtone.id}`}
          onClick={handleDownloadClick}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold text-blue-600 bg-blue-50 hover:bg-blue-600 hover:text-white border border-blue-200/80 active:scale-95 shadow-2xs transition-all cursor-pointer group/dl"
          title={`Download audio file (${ringtone.fileSizeKb} KB)`}
        >
          <Download className="w-3.5 h-3.5" />
          <span className="hidden xs:inline">Download</span>
          <span className="text-[10px] text-blue-500 group-hover/dl:text-white">
            ({(ringtone.downloads >= 1000 ? `${(ringtone.downloads / 1000).toFixed(1)}k` : ringtone.downloads)})
          </span>
        </button>
      </div>

      {/* Approval Rating Bar */}
      <div className="mt-2 flex items-center justify-between text-[10px] text-slate-400">
        <div className="w-full bg-slate-100 rounded-full h-1 overflow-hidden mr-2">
          <div 
            className="bg-blue-600 h-full rounded-full transition-all duration-300"
            style={{ width: `${likePercentage}%` }}
          />
        </div>
        <span className="font-mono text-slate-500 whitespace-nowrap">{likePercentage}% approval</span>
      </div>
    </div>
  );
};
