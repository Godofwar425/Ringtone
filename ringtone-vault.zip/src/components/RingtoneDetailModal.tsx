import React, { useState } from 'react';
import { 
  X, 
  Play, 
  Pause, 
  Download, 
  ThumbsUp, 
  ThumbsDown, 
  Share2, 
  Calendar, 
  HardDrive, 
  Clock, 
  Music, 
  Check,
  Smartphone,
  PhoneCall,
  BellRing,
  AlarmClock,
  Sparkles
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Ringtone } from '../types';

interface RingtoneDetailModalProps {
  ringtone: Ringtone | null;
  isOpen: boolean;
  isPlaying: boolean;
  playbackProgress: number;
  onTogglePlay: (ringtone: Ringtone) => void;
  onSeek: (ringtone: Ringtone, progressRatio: number) => void;
  userRating: 'like' | 'dislike' | 'none';
  onVote: (ringtoneId: string, type: 'like' | 'dislike') => void;
  onDownload: (ringtone: Ringtone) => void;
  onOpenHowToSet: () => void;
  onClose: () => void;
}

export const RingtoneDetailModal: React.FC<RingtoneDetailModalProps> = ({
  ringtone,
  isOpen,
  isPlaying,
  playbackProgress,
  onTogglePlay,
  onSeek,
  userRating,
  onVote,
  onDownload,
  onOpenHowToSet,
  onClose,
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen || !ringtone) return null;

  const totalVotes = ringtone.likes + ringtone.dislikes;
  const likePercentage = totalVotes > 0 ? Math.round((ringtone.likes / totalVotes) * 100) : 100;

  const handleShare = () => {
    navigator.clipboard.writeText(
      `${window.location.origin}?ringtone=${ringtone.id}#${encodeURIComponent(ringtone.title)}`
    );
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadClick = (e: React.MouseEvent) => {
    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
    const x = (rect.left + rect.width / 2) / window.innerWidth;
    const y = (rect.top + rect.height / 2) / window.innerHeight;
    confetti({
      particleCount: 45,
      spread: 70,
      origin: { x, y },
      colors: ['#8b5cf6', '#6366f1', '#06b6d4', '#10b981'],
    });
    onDownload(ringtone);
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  return (
    <div
      id="ringtone-detail-modal-overlay"
      className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto"
      onClick={onClose}
    >
      <div
        id="ringtone-detail-modal-container"
        className="bg-white border border-slate-200 rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl relative my-8 text-slate-800"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50/80">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold px-2.5 py-1 rounded-md bg-blue-50 text-blue-700 border border-blue-200/60 capitalize">
              {ringtone.category}
            </span>
            <span className="text-xs font-semibold px-2.5 py-1 rounded-md bg-slate-100 text-slate-700 border border-slate-200 capitalize">
              {ringtone.type} Tone
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              id="detail-share-btn"
              onClick={handleShare}
              className="p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-md transition-colors cursor-pointer flex items-center gap-1 text-xs"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Share2 className="w-4 h-4" />}
              <span>{copied ? 'Link Copied!' : 'Share'}</span>
            </button>
            <button
              id="detail-close-btn"
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-md transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Main Visual Title Section */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
                {ringtone.title}
              </h2>
              <p className="text-sm text-slate-500 mt-1">
                Uploaded by <span className="text-blue-600 font-semibold">{ringtone.artist}</span> • {ringtone.createdAt}
              </p>
            </div>

            {/* Quick How to set button */}
            <button
              id="detail-how-to-set-btn"
              onClick={() => {
                onClose();
                onOpenHowToSet();
              }}
              className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 border border-slate-200 rounded-md transition-colors shrink-0 cursor-pointer self-start sm:self-auto"
            >
              <Smartphone className="w-4 h-4 text-blue-600" />
              <span>How to Set on Phone</span>
            </button>
          </div>

          {/* Interactive Waveform Audio Visualizer */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 relative overflow-hidden">
            <div className="flex items-center justify-between gap-4 mb-4">
              <button
                id="detail-play-btn"
                onClick={() => onTogglePlay(ringtone)}
                className="w-13 h-13 rounded-full flex items-center justify-center transition-all duration-200 shadow-xs bg-blue-600 hover:bg-blue-700 text-white cursor-pointer"
              >
                {isPlaying ? <Pause className="w-6 h-6 fill-current" /> : <Play className="w-6 h-6 fill-current ml-1" />}
              </button>

              <div className="text-right">
                <span className="text-xs text-slate-500 font-medium">Duration</span>
                <p className="text-lg font-mono font-bold text-slate-900">{formatDuration(ringtone.duration)}</p>
              </div>
            </div>

            {/* High-res Waveform Bars */}
            <div
              id="detail-waveform-bar"
              onClick={(e) => {
                const rect = e.currentTarget.getBoundingClientRect();
                const clickX = e.clientX - rect.left;
                const ratio = Math.max(0, Math.min(1, clickX / rect.width));
                onSeek(ringtone, ratio);
              }}
              className="h-16 flex items-center justify-between gap-1 cursor-pointer py-2 px-2 bg-white rounded-lg border border-slate-200 group/wave select-none"
            >
              {ringtone.waveformData.map((val, idx) => {
                const barRatio = idx / ringtone.waveformData.length;
                const isPast = isPlaying && barRatio <= playbackProgress;
                const heightPct = Math.max(15, Math.round(val * 100));

                return (
                  <div key={idx} className="flex-1 flex items-center justify-center h-full">
                    <div
                      style={{ height: `${heightPct}%` }}
                      className={`w-full max-w-[5px] rounded-full transition-all duration-100 ${
                        isPast
                          ? 'bg-blue-600'
                          : 'bg-slate-300 group-hover/wave:bg-slate-400'
                      }`}
                    />
                  </div>
                );
              })}
            </div>
          </div>

          {/* Rating (Like/Dislike) and Action Bar */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex flex-wrap items-center justify-between gap-4">
            {/* Likes & Dislikes */}
            <div className="flex items-center gap-3">
              <div className="flex bg-white p-1 rounded-lg border border-slate-200 shadow-2xs">
                <button
                  id="detail-like-btn"
                  onClick={() => onVote(ringtone.id, 'like')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-l text-xs font-semibold transition-all cursor-pointer border-r border-slate-200 ${
                    userRating === 'like'
                      ? 'bg-blue-100 text-blue-700'
                      : 'text-slate-600 hover:text-blue-600'
                  }`}
                >
                  <ThumbsUp className={`w-4 h-4 ${userRating === 'like' ? 'fill-current' : ''}`} />
                  <span>{ringtone.likes.toLocaleString()} Likes</span>
                </button>

                <button
                  id="detail-dislike-btn"
                  onClick={() => onVote(ringtone.id, 'dislike')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-r text-xs font-semibold transition-all cursor-pointer ${
                    userRating === 'dislike'
                      ? 'bg-rose-100 text-rose-700'
                      : 'text-slate-600 hover:text-rose-600'
                  }`}
                >
                  <ThumbsDown className={`w-4 h-4 ${userRating === 'dislike' ? 'fill-current' : ''}`} />
                  <span>{ringtone.dislikes.toLocaleString()} Dislikes</span>
                </button>
              </div>

              <span className="text-xs text-blue-600 font-semibold font-mono">
                {likePercentage}% Positive
              </span>
            </div>

            {/* Big Download CTA */}
            <button
              id="detail-download-btn"
              onClick={handleDownloadClick}
              className="flex items-center gap-2 px-5 py-2.5 rounded-md text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 active:scale-98 shadow-xs transition-all cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Download Ringtone ({ringtone.fileSizeKb} KB)</span>
            </button>
          </div>

          {/* Technical Specs & Metadata Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
              <span className="text-slate-500 block mb-1">Format</span>
              <span className="font-semibold text-slate-800">WAV (PCM 16-Bit)</span>
            </div>
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
              <span className="text-slate-500 block mb-1">Sample Rate</span>
              <span className="font-semibold text-slate-800">44.1 kHz Stereo</span>
            </div>
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
              <span className="text-slate-500 block mb-1">Total Downloads</span>
              <span className="font-semibold text-blue-600">{ringtone.downloads.toLocaleString()}</span>
            </div>
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
              <span className="text-slate-500 block mb-1">License</span>
              <span className="font-semibold text-emerald-600">Free Personal Use</span>
            </div>
          </div>

          {/* Tags */}
          <div>
            <span className="text-xs font-semibold text-slate-500 block mb-2">Related Tags:</span>
            <div className="flex flex-wrap gap-2">
              {ringtone.tags.map((tag, idx) => (
                <span
                  key={idx}
                  className="text-xs px-2.5 py-1 bg-slate-100 text-slate-700 rounded-md border border-slate-200 font-medium"
                >
                  #{tag}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
