import React, { useState, useRef } from 'react';
import { 
  X, 
  UploadCloud, 
  Music, 
  Sliders, 
  Sparkles, 
  Play, 
  Pause, 
  Scissors, 
  Check, 
  AlertCircle,
  FileAudio,
  Plus
} from 'lucide-react';
import { Ringtone, RingtoneCategory, ToneType } from '../types';
import { extractWaveformDataFromFile, getAudioContext } from '../utils/audioEngine';
import { CATEGORIES } from '../data/initialRingtones';

interface UploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUploadSuccess: (newRingtone: Ringtone) => void;
}

export const UploadModal: React.FC<UploadModalProps> = ({
  isOpen,
  onClose,
  onUploadSuccess,
}) => {
  const [activeTab, setActiveTab] = useState<'file' | 'synth'>('file');
  
  // File state
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [waveformData, setWaveformData] = useState<number[]>([]);
  const [fileDuration, setFileDuration] = useState<number>(10);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  
  // Metadata fields
  const [title, setTitle] = useState<string>('');
  const [artist, setArtist] = useState<string>('Anonymous Creator');
  const [category, setCategory] = useState<RingtoneCategory>('marimba');
  const [toneType, setToneType] = useState<ToneType>('call');
  const [tagsInput, setTagsInput] = useState<string>('ringtone, music, sound');
  
  // Audio Preview state
  const [isPreviewPlaying, setIsPreviewPlaying] = useState<boolean>(false);
  const audioPreviewRef = useRef<HTMLAudioElement | null>(null);

  // Synth Studio preset options
  const [selectedSynthPreset, setSelectedSynthPreset] = useState<string>('cyberpunk');

  if (!isOpen) return null;

  const handleFileDrop = async (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      await processAudioFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileInputChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      await processAudioFile(e.target.files[0]);
    }
  };

  const processAudioFile = async (file: File) => {
    if (!file.type.startsWith('audio/') && !file.name.match(/\.(mp3|wav|ogg|m4a|aac|flac)$/i)) {
      setErrorMsg('Please select a valid audio file (.mp3, .wav, .ogg, .m4a, .aac)');
      return;
    }

    setErrorMsg(null);
    setIsProcessing(true);
    try {
      const url = URL.createObjectURL(file);
      setAudioUrl(url);
      setUploadedFile(file);

      // Default title from filename
      const cleanName = file.name.replace(/\.[^/.]+$/, '').replace(/[_-]/g, ' ');
      if (!title) {
        setTitle(cleanName.charAt(0).toUpperCase() + cleanName.slice(1));
      }

      // Extract waveform and duration using Web Audio API
      const { waveform, duration } = await extractWaveformDataFromFile(file);
      setWaveformData(waveform);
      setFileDuration(duration);
    } catch (err) {
      console.error('Audio decode error', err);
      // Fallback waveform
      setWaveformData([0.3, 0.5, 0.7, 0.9, 0.6, 0.8, 0.5, 0.7, 0.9, 0.6, 0.8, 0.4, 0.7, 0.9, 0.5, 0.3, 0.6, 0.8, 0.4, 0.3]);
      setFileDuration(15);
    } finally {
      setIsProcessing(false);
    }
  };

  const togglePreviewPlay = () => {
    if (!audioPreviewRef.current) return;
    if (isPreviewPlaying) {
      audioPreviewRef.current.pause();
      setIsPreviewPlaying(false);
    } else {
      audioPreviewRef.current.play().then(() => {
        setIsPreviewPlaying(true);
      }).catch(() => {
        setIsPreviewPlaying(false);
      });
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (activeTab === 'file' && !uploadedFile) {
      setErrorMsg('Please choose an audio file to upload first.');
      return;
    }

    if (!title.trim()) {
      setErrorMsg('Please provide a title for the ringtone.');
      return;
    }

    const tagsArray = tagsInput
      .split(',')
      .map((t) => t.trim().toLowerCase())
      .filter((t) => t.length > 0);

    const newRingtone: Ringtone = {
      id: `custom-${Date.now()}`,
      title: title.trim(),
      artist: artist.trim() || 'Community Creator',
      category: category,
      type: toneType,
      duration: activeTab === 'file' ? fileDuration : 12,
      likes: 1,
      dislikes: 0,
      downloads: 0,
      createdAt: new Date().toISOString().split('T')[0],
      tags: tagsArray.length > 0 ? tagsArray : ['custom', category, toneType],
      waveformData: waveformData.length > 0 ? waveformData : [0.4, 0.6, 0.8, 0.9, 0.7, 0.5, 0.8, 0.95, 0.7, 0.6, 0.8, 0.5, 0.7, 0.9, 0.4, 0.3],
      synthPreset: activeTab === 'synth' ? selectedSynthPreset : undefined,
      audioBlobUrl: activeTab === 'file' && audioUrl ? audioUrl : undefined,
      fileSizeKb: uploadedFile ? Math.round(uploadedFile.size / 1024) : 480,
      featured: false,
    };

    onUploadSuccess(newRingtone);
    onClose();
  };

  return (
    <div
      id="upload-modal-overlay"
      className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-fadeIn"
      onClick={onClose}
    >
      <div
        id="upload-modal-container"
        className="bg-white border border-slate-200 rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl relative my-8 text-slate-800"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50/80">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-50 border border-blue-200/80 flex items-center justify-center text-blue-600">
              <UploadCloud className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-bold text-lg text-slate-900">Upload / Create Ringtone</h2>
              <p className="text-xs text-slate-500">Share your tones with the audio community</p>
            </div>
          </div>
          <button
            id="close-upload-modal-btn"
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-md transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Toggle: File Upload vs Synth Generator */}
        <div className="p-6 pb-2">
          <div className="flex bg-slate-100 p-1 rounded-lg border border-slate-200 text-xs font-semibold">
            <button
              id="upload-tab-file"
              onClick={() => setActiveTab('file')}
              className={`flex-1 py-2 rounded-md flex items-center justify-center gap-2 transition-all cursor-pointer ${
                activeTab === 'file'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <FileAudio className="w-4 h-4" />
              <span>Upload Audio File (.mp3, .wav)</span>
            </button>
            <button
              id="upload-tab-synth"
              onClick={() => setActiveTab('synth')}
              className={`flex-1 py-2 rounded-md flex items-center justify-center gap-2 transition-all cursor-pointer ${
                activeTab === 'synth'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Sparkles className="w-4 h-4" />
              <span>Synthesizer Studio (No file needed)</span>
            </button>
          </div>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 pt-3 space-y-4">
          {errorMsg && (
            <div className="flex items-center gap-2 p-3 bg-rose-50 border border-rose-200 rounded-lg text-rose-700 text-xs">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {activeTab === 'file' ? (
            /* File Upload Section */
            <div>
              {!uploadedFile ? (
                <div
                  id="dropzone-upload"
                  onDragOver={(e) => e.preventDefault()}
                  onDrop={handleFileDrop}
                  className="border-2 border-dashed border-slate-300 hover:border-blue-500 bg-slate-50/50 hover:bg-slate-50 rounded-xl p-6 text-center transition-all cursor-pointer group"
                  onClick={() => document.getElementById('file-upload-input')?.click()}
                >
                  <input
                    id="file-upload-input"
                    type="file"
                    accept="audio/*,.mp3,.wav,.ogg,.m4a,.flac,.aac"
                    onChange={handleFileInputChange}
                    className="hidden"
                  />
                  <div className="w-12 h-12 rounded-full bg-blue-50 border border-blue-200/80 text-blue-600 flex items-center justify-center mx-auto mb-3 group-hover:scale-105 transition-transform">
                    <UploadCloud className="w-6 h-6" />
                  </div>
                  <p className="text-sm font-semibold text-slate-800">
                    Click to browse or drag & drop audio here
                  </p>
                  <p className="text-xs text-slate-500 mt-1">
                    Supports MP3, WAV, OGG, M4A, AAC up to 25MB
                  </p>
                </div>
              ) : (
                <div className="bg-slate-50 border border-slate-200 rounded-xl p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2.5">
                      <FileAudio className="w-5 h-5 text-blue-600" />
                      <div>
                        <p className="text-sm font-semibold text-slate-900 truncate max-w-xs">{uploadedFile.name}</p>
                        <p className="text-xs text-slate-500">
                          {(uploadedFile.size / (1024 * 1024)).toFixed(2)} MB • {fileDuration}s duration
                        </p>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setUploadedFile(null);
                        setAudioUrl(null);
                      }}
                      className="text-xs text-rose-600 hover:text-rose-700 font-medium p-1 cursor-pointer"
                    >
                      Remove
                    </button>
                  </div>

                  {/* Audio Preview element */}
                  {audioUrl && (
                    <div className="flex items-center gap-3 bg-white p-2.5 rounded-lg border border-slate-200 shadow-2xs">
                      <audio
                        ref={audioPreviewRef}
                        src={audioUrl}
                        onEnded={() => setIsPreviewPlaying(false)}
                      />
                      <button
                        type="button"
                        onClick={togglePreviewPlay}
                        className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center shrink-0 cursor-pointer"
                      >
                        {isPreviewPlaying ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current ml-0.5" />}
                      </button>
                      
                      {/* Mini waveform preview */}
                      <div className="flex-1 h-6 flex items-center gap-[2px]">
                        {waveformData.map((val, idx) => (
                          <div
                            key={idx}
                            style={{ height: `${Math.max(20, Math.round(val * 100))}%` }}
                            className="flex-1 bg-blue-600 rounded-full"
                          />
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          ) : (
            /* Synthesizer Studio Tab */
            <div className="space-y-3">
              <label className="block text-xs font-semibold text-slate-700">
                Choose Sound Engine Preset:
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[
                  { id: 'cyberpunk', name: 'Cyberpunk Synth', desc: '80s Arp & Bass' },
                  { id: 'marimba', name: 'Marimba Trap', desc: 'Tropical Bell' },
                  { id: 'tokyo_phonk', name: 'Tokyo Phonk', desc: 'Cowbell & 808' },
                  { id: 'nokia_retro', name: 'Retro 8-Bit', desc: 'Nokia Nostalgia' },
                  { id: 'zen_chime', name: 'Zen Chime', desc: 'Peaceful Ambient' },
                  { id: 'pixel_quest', name: 'Arcade Level Up', desc: 'Gameboy Fanfare' },
                  { id: 'lofi_guitar', name: 'Lo-Fi Rain', desc: 'Warm Rhodes' },
                  { id: 'minimal_pulse', name: 'Minimal Pulse', desc: 'Apple Crystal' },
                ].map((synth) => (
                  <button
                    key={synth.id}
                    type="button"
                    onClick={() => {
                      setSelectedSynthPreset(synth.id);
                      if (!title) setTitle(synth.name);
                    }}
                    className={`p-2.5 rounded-lg border text-left transition-all cursor-pointer ${
                      selectedSynthPreset === synth.id
                        ? 'bg-blue-50 border-blue-500 text-blue-900 shadow-2xs'
                        : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    <p className="text-xs font-bold text-slate-900">{synth.name}</p>
                    <p className="text-[10px] text-slate-500">{synth.desc}</p>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Metadata Inputs */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Ringtone Title *
              </label>
              <input
                id="upload-title-input"
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Modern Horizon"
                className="w-full bg-slate-50 text-sm text-slate-900 px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:border-blue-500 focus:bg-white transition-colors"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Artist / Creator Name
              </label>
              <input
                id="upload-artist-input"
                type="text"
                value={artist}
                onChange={(e) => setArtist(e.target.value)}
                placeholder="e.g. SoundWave Pro"
                className="w-full bg-slate-50 text-sm text-slate-900 px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:border-blue-500 focus:bg-white transition-colors"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Category / Genre
              </label>
              <select
                id="upload-category-select"
                value={category}
                onChange={(e) => setCategory(e.target.value as RingtoneCategory)}
                className="w-full bg-slate-50 text-sm text-slate-900 px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:border-blue-500 focus:bg-white cursor-pointer capitalize transition-colors"
              >
                {CATEGORIES.filter((c) => c.id !== 'all').map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.label}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Tone Type
              </label>
              <select
                id="upload-type-select"
                value={toneType}
                onChange={(e) => setToneType(e.target.value as ToneType)}
                className="w-full bg-slate-50 text-sm text-slate-900 px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:border-blue-500 focus:bg-white cursor-pointer transition-colors"
              >
                <option value="call">Call Ringtone</option>
                <option value="notification">Notification / SMS Alert</option>
                <option value="alarm">Alarm Sound</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Tags (comma separated)
            </label>
            <input
              id="upload-tags-input"
              type="text"
              value={tagsInput}
              onChange={(e) => setTagsInput(e.target.value)}
              placeholder="e.g. modern, acoustic, alert, clean"
              className="w-full bg-slate-50 text-sm text-slate-900 px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:border-blue-500 focus:bg-white transition-colors"
            />
          </div>

          {/* Submit / Cancel Buttons */}
          <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2">
            <button
              type="button"
              id="cancel-upload-btn"
              onClick={onClose}
              className="px-4 py-2 rounded-md text-xs font-semibold text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 border border-slate-200 transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              id="submit-upload-btn"
              disabled={isProcessing}
              className="flex items-center gap-2 px-5 py-2 rounded-md text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 active:scale-98 shadow-xs transition-all cursor-pointer disabled:opacity-50"
            >
              <Check className="w-4 h-4" />
              <span>Publish Ringtone</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
