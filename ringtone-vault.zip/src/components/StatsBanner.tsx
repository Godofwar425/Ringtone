import React from 'react';
import { Sparkles, Download, Volume2, Users, UploadCloud, Smartphone } from 'lucide-react';

interface StatsBannerProps {
  totalTones: number;
  totalDownloads: number;
  onOpenUpload: () => void;
  onOpenHowToSet: () => void;
}

export const StatsBanner: React.FC<StatsBannerProps> = ({
  totalTones,
  totalDownloads,
  onOpenUpload,
  onOpenHowToSet,
}) => {
  return (
    <div
      id="hero-stats-banner"
      className="relative overflow-hidden rounded-2xl bg-white border border-slate-200 p-6 sm:p-8 my-6 shadow-sm"
    >
      {/* Background ambient elements */}
      <div className="absolute -right-12 -top-12 w-64 h-64 bg-blue-50 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -left-12 -bottom-12 w-64 h-64 bg-slate-100 rounded-full blur-3xl pointer-events-none" />

      <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div className="max-w-2xl">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-200/60 mb-3">
            <Sparkles className="w-3.5 h-3.5 text-blue-600" />
            <span>Discover &amp; Download Free Ringtones</span>
          </div>

          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-slate-900 tracking-tight leading-tight">
            High quality ringtones, alerts &amp; <span className="text-blue-600">custom sounds</span>
          </h1>

          <p className="text-sm text-slate-600 mt-2.5 leading-relaxed max-w-xl">
            Stream, rate with likes &amp; dislikes, upload your own sound clips, and download high-definition ringtones, SMS alerts, and alarm chimes for Android &amp; iPhone.
          </p>

          <div className="flex flex-wrap items-center gap-3 mt-5">
            <button
              id="banner-upload-cta"
              onClick={onOpenUpload}
              className="flex items-center gap-2 px-5 py-2.5 rounded-md text-xs sm:text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 active:scale-98 shadow-xs transition-all cursor-pointer"
            >
              <UploadCloud className="w-4 h-4" />
              <span>Upload Ringtone</span>
            </button>
            <button
              id="banner-guide-cta"
              onClick={onOpenHowToSet}
              className="flex items-center gap-2 px-4 py-2.5 rounded-md text-xs sm:text-sm font-semibold text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200/80 border border-slate-200 transition-all cursor-pointer"
            >
              <Smartphone className="w-4 h-4 text-blue-600" />
              <span>How to Set Ringtone</span>
            </button>
          </div>
        </div>

        {/* Live Counters */}
        <div className="grid grid-cols-3 gap-3 sm:gap-4 shrink-0 bg-slate-50 p-4 rounded-xl border border-slate-200/80">
          <div className="text-center px-2">
            <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-600 flex items-center justify-center mx-auto mb-1.5">
              <Volume2 className="w-4 h-4" />
            </div>
            <p className="text-lg sm:text-xl font-bold text-slate-900 font-mono">{totalTones}</p>
            <p className="text-[11px] text-slate-500 font-medium">Free Tones</p>
          </div>

          <div className="text-center px-2 border-x border-slate-200">
            <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-600 flex items-center justify-center mx-auto mb-1.5">
              <Download className="w-4 h-4" />
            </div>
            <p className="text-lg sm:text-xl font-bold text-slate-900 font-mono">
              {(totalDownloads / 1000).toFixed(1)}k+
            </p>
            <p className="text-[11px] text-slate-500 font-medium">Downloads</p>
          </div>

          <div className="text-center px-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto mb-1.5">
              <Users className="w-4 h-4" />
            </div>
            <p className="text-lg sm:text-xl font-bold text-emerald-600 font-mono">100%</p>
            <p className="text-[11px] text-slate-500 font-medium">Free Tier</p>
          </div>
        </div>
      </div>
    </div>
  );
};
