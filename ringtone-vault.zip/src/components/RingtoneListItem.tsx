import React from 'react';
import { 
  Play, 
  Pause, 
  Download, 
  ThumbsUp, 
  ThumbsDown, 
  Share2, 
  Info,
  PhoneCall,
  BellRing,
  AlarmClock
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Ringtone } from '../types';

interface RingtoneListItemProps {
  ringtone: Ringtone;
  isPlaying: boolean;
  playbackProgress: number;
  onTogglePlay: (ringtone: Ringtone) => void;
  onSeek: (ringtone: Ringtone, progressRatio: number) => void;
  userRating: 'like' | 'dislike' | 'none';
  onVote: (ringtoneId: string, type: 'like' | 'dislike') => void;
  onDownload: (ringtone: Ringtone) => void;
  onOpenDetails: (ringtone: Ringtone) => void;
}

export const RingtoneListItem: React.FC<RingtoneListItemProps> = ({
  ringtone,
  isPlaying,
  playbackProgress,
  onTogglePlay,
  onSeek,
  userRating,
  onVote,
  onDownload,
  onOpenDetails,
}) => {
  const handleDownloadClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
    const x = (rect.left + rect.width / 2) / window.innerWidth;
    const y = (rect.top + rect.height / 2) / window.innerHeight;
    confetti({
      particleCount: 30,
      spread: 50,
      origin: { x, y },
      colors: ['#8b5cf6', '#6366f1', '#06b6d4', '#10b981'],
    });
    onDownload(ringtone);
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  const getTypeIcon = () => {
    switch (ringtone.type) {
      case 'call': return <PhoneCall className="w-3 h-3 text-emerald-400" />;
      case 'notification': return <BellRing className="w-3 h-3 text-amber-400" />;
      case 'alarm': return <AlarmClock className="w-3 h-3 text-rose-400" />;
    }
  };

  return (
    <div
      id={`ringtone-list-item-${ringtone.id}`}
      className={`group bg-white hover:bg-slate-50/70 border rounded-xl p-3 sm:p-4 transition-all duration-150 flex flex-col md:flex-row md:items-center justify-between gap-3 shadow-2xs hover:border-blue-200 ${
        isPlaying 
          ? 'border-blue-500 ring-2 ring-blue-500/20 bg-blue-50/15' 
          : 'border-slate-200'
      }`}
    >
      {/* Left Info & Play Button */}
      <div className="flex items-center gap-3 min-w-[240px]">
        <button
          id={`list-play-btn-${ringtone.id}`}
          onClick={() => onTogglePlay(ringtone)}
          className={`w-10 h-10 shrink-0 rounded-full flex items-center justify-center transition-all cursor-pointer ${
            isPlaying
              ? 'bg-blue-600 text-white shadow-xs'
              : 'bg-blue-50 hover:bg-blue-600 text-blue-600 hover:text-white'
          }`}
          aria-label={isPlaying ? 'Pause ringtone' : 'Play ringtone'}
        >
          {isPlaying ? (
            <Pause className="w-4 h-4 fill-current" />
          ) : (
            <Play className="w-4 h-4 fill-current ml-0.5" />
          )}
        </button>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <h4
              onClick={() => onOpenDetails(ringtone)}
              className="font-bold text-slate-900 text-sm hover:text-blue-600 transition-colors cursor-pointer truncate"
            >
              {ringtone.title}
            </h4>
            <span className="shrink-0 inline-flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded-md bg-slate-100 border border-slate-200 text-slate-700">
              {getTypeIcon()}
              <span className="capitalize">{ringtone.type}</span>
            </span>
          </div>
          <p className="text-xs text-slate-500 font-medium truncate">
            {ringtone.artist} • <span className="capitalize">{ringtone.category}</span> • {formatDuration(ringtone.duration)}
          </p>
        </div>
      </div>

      {/* Middle: Waveform Bar */}
      <div 
        id={`list-waveform-${ringtone.id}`}
        onClick={(e) => {
          const rect = e.currentTarget.getBoundingClientRect();
          const clickX = e.clientX - rect.left;
          const ratio = Math.max(0, Math.min(1, clickX / rect.width));
          onSeek(ringtone, ratio);
        }}
        className="flex-1 h-8 flex items-center justify-between gap-[2px] cursor-pointer py-1 px-2 bg-slate-50 rounded-lg border border-slate-200 group/wave select-none min-w-[160px] max-w-xl"
        title="Click to seek"
      >
        {ringtone.waveformData.map((val, idx) => {
          const barRatio = idx / ringtone.waveformData.length;
          const isPast = isPlaying && barRatio <= playbackProgress;
          const heightPct = Math.max(20, Math.round(val * 100));

          return (
            <div key={idx} className="flex-1 flex items-center justify-center h-full">
              <div
                style={{ height: `${heightPct}%` }}
                className={`w-full max-w-[3px] rounded-full transition-all duration-100 ${
                  isPast
                    ? 'bg-blue-600'
                    : 'bg-slate-300 group-hover/wave:bg-slate-400'
                }`}
              />
            </div>
          );
        })}
      </div>

      {/* Right: Likes/Dislikes & Download Button */}
      <div className="flex items-center justify-between md:justify-end gap-3">
        {/* Like / Dislike */}
        <div className="flex items-center bg-slate-50 p-1 rounded-lg border border-slate-200">
          <button
            id={`list-like-btn-${ringtone.id}`}
            onClick={() => onVote(ringtone.id, 'like')}
            className={`flex items-center gap-1 px-2 py-1 rounded-l text-xs font-semibold cursor-pointer border-r border-slate-200 ${
              userRating === 'like'
                ? 'bg-blue-100 text-blue-700'
                : 'text-slate-600 hover:text-blue-600'
            }`}
          >
            <ThumbsUp className={`w-3.5 h-3.5 ${userRating === 'like' ? 'fill-current' : ''}`} />
            <span className="text-[10px] font-bold">{ringtone.likes >= 1000 ? `${(ringtone.likes / 1000).toFixed(1)}k` : ringtone.likes}</span>
          </button>
          <button
            id={`list-dislike-btn-${ringtone.id}`}
            onClick={() => onVote(ringtone.id, 'dislike')}
            className={`flex items-center gap-1 px-2 py-1 rounded-r text-xs font-semibold cursor-pointer ${
              userRating === 'dislike'
                ? 'bg-rose-100 text-rose-700'
                : 'text-slate-600 hover:text-rose-600'
            }`}
          >
            <ThumbsDown className={`w-3.5 h-3.5 ${userRating === 'dislike' ? 'fill-current' : ''}`} />
            <span className="text-[10px] font-bold">{ringtone.dislikes >= 1000 ? `${(ringtone.dislikes / 1000).toFixed(1)}k` : ringtone.dislikes}</span>
          </button>
        </div>

        {/* Download Button */}
        <button
          id={`list-download-btn-${ringtone.id}`}
          onClick={handleDownloadClick}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 transition-colors cursor-pointer shadow-2xs"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Download</span>
        </button>

        {/* Info button */}
        <button
          id={`list-info-btn-${ringtone.id}`}
          onClick={() => onOpenDetails(ringtone)}
          className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-md transition-colors cursor-pointer"
          title="Details"
        >
          <Info className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
