import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Ringtone, RingtoneCategory, ToneType, SortFilter, UserRatingState, AudioPlaybackState } from './types';
import { INITIAL_RINGTONES } from './data/initialRingtones';
import { Header } from './components/Header';
import { CategoryFilter } from './components/CategoryFilter';
import { RingtoneCard } from './components/RingtoneCard';
import { RingtoneListItem } from './components/RingtoneListItem';
import { StickyAudioPlayer } from './components/StickyAudioPlayer';
import { UploadModal } from './components/UploadModal';
import { HowToSetModal } from './components/HowToSetModal';
import { RingtoneDetailModal } from './components/RingtoneDetailModal';
import { StatsBanner } from './components/StatsBanner';
import { globalAudioPlayer, triggerRingtoneDownload } from './utils/audioEngine';
import { Music, Search, SlidersHorizontal, Sparkles, Upload, PhoneCall, BellRing, AlarmClock } from 'lucide-react';

const STORAGE_KEY_RINGTONES = 'ringtone_vault_items_v1';
const STORAGE_KEY_RATINGS = 'ringtone_vault_user_ratings_v1';

export default function App() {
  // Ringtones State with LocalStorage persistence
  const [ringtones, setRingtones] = useState<Ringtone[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_RINGTONES);
      if (saved) {
        const parsed = JSON.parse(saved);
        // Merge initial with uploaded if needed
        const customItems = parsed.filter((item: Ringtone) => item.id.startsWith('custom-'));
        return [...INITIAL_RINGTONES, ...customItems];
      }
    } catch (e) {
      console.error('Error loading saved ringtones', e);
    }
    return INITIAL_RINGTONES;
  });

  // User Rating State (likes / dislikes)
  const [userRatings, setUserRatings] = useState<UserRatingState>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_RATINGS);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Error loading user ratings', e);
    }
    return {};
  });

  // Filters and Navigation State
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<RingtoneCategory>('all');
  const [selectedToneType, setSelectedToneType] = useState<ToneType | 'all'>('all');
  const [sortFilter, setSortFilter] = useState<SortFilter>('trending');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  // Modals state
  const [isUploadOpen, setIsUploadOpen] = useState<boolean>(false);
  const [isHowToSetOpen, setIsHowToSetOpen] = useState<boolean>(false);
  const [detailRingtone, setDetailRingtone] = useState<Ringtone | null>(null);

  // Audio Playback State
  const [playbackState, setPlaybackState] = useState<AudioPlaybackState>({
    currentRingtoneId: null,
    isPlaying: false,
    currentTime: 0,
    duration: 12,
    volume: 0.8,
    isMuted: false,
    isLooping: false,
  });

  // Save Ringtones to LocalStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_RINGTONES, JSON.stringify(ringtones));
    } catch (e) {
      console.error('Error saving ringtones to localStorage', e);
    }
  }, [ringtones]);

  // Save User Ratings to LocalStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_RATINGS, JSON.stringify(userRatings));
    } catch (e) {
      console.error('Error saving user ratings', e);
    }
  }, [userRatings]);

  // Setup Audio Player callbacks
  useEffect(() => {
    globalAudioPlayer.setCallbacks(
      (currentTime: number) => {
        setPlaybackState((prev) => ({ ...prev, currentTime }));
      },
      () => {
        setPlaybackState((prev) => ({ ...prev, isPlaying: false, currentTime: 0 }));
      }
    );
  }, []);

  // Find Current Ringtone object
  const currentRingtone = useMemo(() => {
    return ringtones.find((r) => r.id === playbackState.currentRingtoneId) || null;
  }, [ringtones, playbackState.currentRingtoneId]);

  // Toggle Play / Pause
  const handleTogglePlay = useCallback(async (ringtone: Ringtone) => {
    if (playbackState.currentRingtoneId === ringtone.id && playbackState.isPlaying) {
      globalAudioPlayer.pause();
      setPlaybackState((prev) => ({ ...prev, isPlaying: false }));
    } else {
      const isSameTrack = playbackState.currentRingtoneId === ringtone.id;
      const startOffset = isSameTrack ? playbackState.currentTime : 0;
      
      setPlaybackState((prev) => ({
        ...prev,
        currentRingtoneId: ringtone.id,
        isPlaying: true,
        duration: ringtone.duration,
        currentTime: startOffset,
      }));

      await globalAudioPlayer.playRingtone(
        ringtone.id,
        ringtone.synthPreset,
        ringtone.audioBlobUrl,
        startOffset
      );
    }
  }, [playbackState.currentRingtoneId, playbackState.isPlaying, playbackState.currentTime]);

  // Waveform Seek
  const handleSeek = useCallback((ringtone: Ringtone, progressRatio: number) => {
    const seekTime = progressRatio * ringtone.duration;
    setPlaybackState((prev) => ({
      ...prev,
      currentRingtoneId: ringtone.id,
      currentTime: seekTime,
      duration: ringtone.duration,
      isPlaying: true,
    }));

    globalAudioPlayer.playRingtone(
      ringtone.id,
      ringtone.synthPreset,
      ringtone.audioBlobUrl,
      seekTime
    );
  }, []);

  // Sticky Player Seek
  const handleStickySeek = useCallback((seconds: number) => {
    if (!currentRingtone) return;
    setPlaybackState((prev) => ({ ...prev, currentTime: seconds }));
    globalAudioPlayer.playRingtone(
      currentRingtone.id,
      currentRingtone.synthPreset,
      currentRingtone.audioBlobUrl,
      seconds
    );
  }, [currentRingtone]);

  // Loop Toggle
  const handleToggleLoop = useCallback(() => {
    setPlaybackState((prev) => {
      const nextLoop = !prev.isLooping;
      globalAudioPlayer.setLoop(nextLoop);
      return { ...prev, isLooping: nextLoop };
    });
  }, []);

  // Volume Change
  const handleVolumeChange = useCallback((vol: number) => {
    setPlaybackState((prev) => {
      globalAudioPlayer.setVolume(vol);
      return { ...prev, volume: vol, isMuted: vol === 0 };
    });
  }, []);

  // Mute Toggle
  const handleToggleMute = useCallback(() => {
    setPlaybackState((prev) => {
      const nextMuted = !prev.isMuted;
      globalAudioPlayer.setVolume(nextMuted ? 0 : prev.volume || 0.8);
      return { ...prev, isMuted: nextMuted };
    });
  }, []);

  // Previous Track
  const handlePreviousTrack = useCallback(() => {
    if (!currentRingtone) return;
    const currentIndex = ringtones.findIndex((r) => r.id === currentRingtone.id);
    const prevIndex = (currentIndex - 1 + ringtones.length) % ringtones.length;
    handleTogglePlay(ringtones[prevIndex]);
  }, [currentRingtone, ringtones, handleTogglePlay]);

  // Next Track
  const handleNextTrack = useCallback(() => {
    if (!currentRingtone) return;
    const currentIndex = ringtones.findIndex((r) => r.id === currentRingtone.id);
    const nextIndex = (currentIndex + 1) % ringtones.length;
    handleTogglePlay(ringtones[nextIndex]);
  }, [currentRingtone, ringtones, handleTogglePlay]);

  // Like / Dislike voting handler
  const handleVote = useCallback((ringtoneId: string, voteType: 'like' | 'dislike') => {
    setUserRatings((prevRatings) => {
      const currentVote = prevRatings[ringtoneId] || 'none';
      let newVote: 'like' | 'dislike' | 'none' = voteType;

      if (currentVote === voteType) {
        // Toggle off back to none
        newVote = 'none';
      }

      // Update ringtones like/dislike counts
      setRingtones((prevList) =>
        prevList.map((item) => {
          if (item.id !== ringtoneId) return item;

          let deltaLikes = 0;
          let deltaDislikes = 0;

          if (currentVote === 'like') deltaLikes -= 1;
          if (currentVote === 'dislike') deltaDislikes -= 1;

          if (newVote === 'like') deltaLikes += 1;
          if (newVote === 'dislike') deltaDislikes += 1;

          return {
            ...item,
            likes: Math.max(0, item.likes + deltaLikes),
            dislikes: Math.max(0, item.dislikes + deltaDislikes),
          };
        })
      );

      return {
        ...prevRatings,
        [ringtoneId]: newVote,
      };
    });
  }, []);

  // Download Handler
  const handleDownload = useCallback(async (ringtone: Ringtone) => {
    // Increment download counter
    setRingtones((prev) =>
      prev.map((r) => (r.id === ringtone.id ? { ...r, downloads: r.downloads + 1 } : r))
    );

    // Trigger real file download
    await triggerRingtoneDownload(ringtone.title, ringtone.synthPreset, ringtone.audioBlobUrl);
  }, []);

  // New Ringtone Uploaded
  const handleUploadSuccess = useCallback((newRingtone: Ringtone) => {
    setRingtones((prev) => [newRingtone, ...prev]);
    // Auto play newly created tone
    handleTogglePlay(newRingtone);
  }, [handleTogglePlay]);

  // Category item counts
  const categoryCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    ringtones.forEach((r) => {
      counts[r.category] = (counts[r.category] || 0) + 1;
    });
    return counts;
  }, [ringtones]);

  // Filtered & Sorted Ringtones
  const filteredRingtones = useMemo(() => {
    return ringtones
      .filter((r) => {
        // Category Filter
        if (selectedCategory !== 'all' && r.category !== selectedCategory) {
          return false;
        }
        // Tone Type Filter
        if (selectedToneType !== 'all' && r.type !== selectedToneType) {
          return false;
        }
        // Search Query Filter
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchTitle = r.title.toLowerCase().includes(q);
          const matchArtist = r.artist.toLowerCase().includes(q);
          const matchCategory = r.category.toLowerCase().includes(q);
          const matchTags = r.tags.some((t) => t.toLowerCase().includes(q));
          if (!matchTitle && !matchArtist && !matchCategory && !matchTags) {
            return false;
          }
        }
        return true;
      })
      .sort((a, b) => {
        if (sortFilter === 'trending') {
          // Weighted score: likes + downloads * 0.2
          const scoreA = a.likes * 2 + a.downloads * 0.1 - a.dislikes;
          const scoreB = b.likes * 2 + b.downloads * 0.1 - b.dislikes;
          return scoreB - scoreA;
        }
        if (sortFilter === 'popular') {
          return b.downloads - a.downloads;
        }
        if (sortFilter === 'most_liked') {
          return b.likes - a.likes;
        }
        if (sortFilter === 'newest') {
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
        }
        return 0;
      });
  }, [ringtones, selectedCategory, selectedToneType, searchQuery, sortFilter]);

  const totalDownloads = useMemo(() => {
    return ringtones.reduce((sum, r) => sum + r.downloads, 0);
  }, [ringtones]);

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-800 flex flex-col font-sans selection:bg-blue-600 selection:text-white pb-32">
      {/* Header */}
      <Header
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        selectedToneType={selectedToneType}
        onSelectToneType={setSelectedToneType}
        sortFilter={sortFilter}
        onSortChange={setSortFilter}
        viewMode={viewMode}
        onViewModeChange={setViewMode}
        onOpenUpload={() => setIsUploadOpen(true)}
        onOpenHowToSet={() => setIsHowToSetOpen(true)}
        totalTonesCount={ringtones.length}
      />

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full flex-1">
        {/* Hero & Stats Banner */}
        <StatsBanner
          totalTones={ringtones.length}
          totalDownloads={totalDownloads}
          onOpenUpload={() => setIsUploadOpen(true)}
          onOpenHowToSet={() => setIsHowToSetOpen(true)}
        />

        {/* Category Horizontal Pills Filter */}
        <CategoryFilter
          activeCategory={selectedCategory}
          onSelectCategory={setSelectedCategory}
          categoryCounts={categoryCounts}
        />

        {/* Section Title & Active Filter Summary */}
        <div className="flex items-center justify-between my-4">
          <div className="flex items-center gap-2">
            <h2 className="text-lg sm:text-xl font-bold text-slate-900 tracking-tight capitalize">
              {selectedCategory === 'all' ? 'All Popular Ringtones' : `${selectedCategory} Tones`}
            </h2>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-slate-100 border border-slate-200 text-slate-600 font-mono font-medium">
              {filteredRingtones.length} results
            </span>
          </div>

          {(searchQuery || selectedCategory !== 'all' || selectedToneType !== 'all') && (
            <button
              id="reset-all-filters-btn"
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('all');
                setSelectedToneType('all');
              }}
              className="text-xs font-semibold text-blue-600 hover:text-blue-700 transition-colors cursor-pointer"
            >
              Reset Filters
            </button>
          )}
        </div>

        {/* Ringtone Feed (Grid vs List) */}
        {filteredRingtones.length === 0 ? (
          <div
            id="empty-results-container"
            className="text-center py-16 px-4 bg-white rounded-2xl border border-slate-200 shadow-2xs my-6"
          >
            <div className="w-14 h-14 rounded-2xl bg-blue-50 border border-blue-200/80 text-blue-600 flex items-center justify-center mx-auto mb-4">
              <Search className="w-7 h-7" />
            </div>
            <h3 className="text-lg font-bold text-slate-900">No matching ringtones found</h3>
            <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
              We couldn't find any tones matching "{searchQuery}". Try a different keyword or create your own custom tone!
            </p>
            <div className="mt-5 flex items-center justify-center gap-3">
              <button
                id="empty-reset-btn"
                onClick={() => {
                  setSearchQuery('');
                  setSelectedCategory('all');
                  setSelectedToneType('all');
                }}
                className="px-4 py-2 rounded-md text-xs font-semibold text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 border border-slate-200 transition-colors cursor-pointer"
              >
                Clear Search
              </button>
              <button
                id="empty-upload-btn"
                onClick={() => setIsUploadOpen(true)}
                className="px-4 py-2 rounded-md text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 shadow-xs transition-colors cursor-pointer"
              >
                Upload / Create Tone
              </button>
            </div>
          </div>
        ) : viewMode === 'grid' ? (
          <div
            id="ringtones-grid-container"
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-5"
          >
            {filteredRingtones.map((ringtone) => {
              const isPlaying = playbackState.currentRingtoneId === ringtone.id && playbackState.isPlaying;
              const progressRatio = ringtone.duration > 0 ? playbackState.currentTime / ringtone.duration : 0;

              return (
                <RingtoneCard
                  key={ringtone.id}
                  ringtone={ringtone}
                  isPlaying={isPlaying}
                  playbackProgress={progressRatio}
                  onTogglePlay={handleTogglePlay}
                  onSeek={handleSeek}
                  userRating={userRatings[ringtone.id] || 'none'}
                  onVote={handleVote}
                  onDownload={handleDownload}
                  onOpenDetails={setDetailRingtone}
                />
              );
            })}
          </div>
        ) : (
          <div id="ringtones-list-container" className="space-y-2.5">
            {filteredRingtones.map((ringtone) => {
              const isPlaying = playbackState.currentRingtoneId === ringtone.id && playbackState.isPlaying;
              const progressRatio = ringtone.duration > 0 ? playbackState.currentTime / ringtone.duration : 0;

              return (
                <RingtoneListItem
                  key={ringtone.id}
                  ringtone={ringtone}
                  isPlaying={isPlaying}
                  playbackProgress={progressRatio}
                  onTogglePlay={handleTogglePlay}
                  onSeek={handleSeek}
                  userRating={userRatings[ringtone.id] || 'none'}
                  onVote={handleVote}
                  onDownload={handleDownload}
                  onOpenDetails={setDetailRingtone}
                />
              );
            })}
          </div>
        )}
      </main>

      {/* Sticky Bottom Audio Player */}
      <StickyAudioPlayer
        currentRingtone={currentRingtone}
        playbackState={playbackState}
        onTogglePlay={() => {
          if (currentRingtone) handleTogglePlay(currentRingtone);
        }}
        onSeek={handleStickySeek}
        onToggleLoop={handleToggleLoop}
        onVolumeChange={handleVolumeChange}
        onToggleMute={handleToggleMute}
        onPrevious={handlePreviousTrack}
        onNext={handleNextTrack}
        onClose={() => {
          globalAudioPlayer.stop();
          setPlaybackState((prev) => ({ ...prev, currentRingtoneId: null, isPlaying: false }));
        }}
        userRating={currentRingtone ? (userRatings[currentRingtone.id] || 'none') : 'none'}
        onVote={handleVote}
        onDownload={handleDownload}
        onOpenDetails={setDetailRingtone}
      />

      {/* Upload Modal */}
      <UploadModal
        isOpen={isUploadOpen}
        onClose={() => setIsUploadOpen(false)}
        onUploadSuccess={handleUploadSuccess}
      />

      {/* How to Set Tone Guide Modal */}
      <HowToSetModal
        isOpen={isHowToSetOpen}
        onClose={() => setIsHowToSetOpen(false)}
      />

      {/* Ringtone Details & Specs Modal */}
      <RingtoneDetailModal
        ringtone={detailRingtone}
        isOpen={Boolean(detailRingtone)}
        isPlaying={Boolean(detailRingtone && playbackState.currentRingtoneId === detailRingtone.id && playbackState.isPlaying)}
        playbackProgress={
          detailRingtone && detailRingtone.duration > 0
            ? playbackState.currentTime / detailRingtone.duration
            : 0
        }
        onTogglePlay={handleTogglePlay}
        onSeek={handleSeek}
        userRating={detailRingtone ? (userRatings[detailRingtone.id] || 'none') : 'none'}
        onVote={handleVote}
        onDownload={handleDownload}
        onOpenHowToSet={() => setIsHowToSetOpen(true)}
        onClose={() => setDetailRingtone(null)}
      />
    </div>
  );
}
